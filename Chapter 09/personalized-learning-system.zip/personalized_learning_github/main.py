"""
Personalized Learning System Main Entry Point

This module serves as the primary entry point for the personalized learning system.
It initializes all necessary components including configuration, logging, content 
generation, and simulation management to demonstrate the system's capabilities
through a comprehensive learning simulation.

Author: Personalized Learning Team
License: MIT
"""

import asyncio
import os
from dotenv import load_dotenv

from src.simulation.simulator import LearningSimulator
from src.utils.config import load_config
from src.utils.logger import setup_logging
from src.core.content_generator import ContentGenerator


async def main():
    """
    Main execution function for the personalized learning system.
    
    This function orchestrates the entire simulation process by:
    1. Loading environment variables and configuration settings
    2. Setting up logging infrastructure
    3. Initializing the AI-powered content generator
    4. Creating and running a learning simulation
    5. Generating comprehensive performance reports
    
    The simulation demonstrates how the system can handle multiple students
    with different learning profiles, generate personalized content, and
    track progress over multiple learning sessions.
    
    Raises:
        ValueError: If required environment variables (like OPENAI_API_KEY) are missing
        Exception: For any other configuration or initialization errors
    """
    try:
        # Load environment variables from .env file
        # This includes sensitive data like API keys
        load_dotenv()
        
        # Load system configuration from YAML files
        # Contains settings for content generation, assessment, etc.
        config = load_config()
        
        # Initialize logging system for monitoring and debugging
        setup_logging()

        # Initialize the AI-powered content generator
        # Uses OpenAI's GPT models to create personalized learning content
        content_generator = ContentGenerator(
            api_key=os.getenv("OPENAI_API_KEY"),
            model=config.get("model", "gpt-4")  # Default to GPT-4 if not configured
        )

        # Create the learning simulation environment
        # This will simulate multiple students with different learning profiles
        simulator = LearningSimulator(
            num_students=config.get("simulation.num_students", 100),  # Default 100 students
            content_generator=content_generator
        )

        # Initialize the student population with diverse learning profiles
        # Creates students with different strengths, weaknesses, and learning styles
        simulator.initialize_population()
        
        # Run the main simulation loop
        # Each session generates personalized content and tracks student progress
        await simulator.run_simulation(
            num_sessions=config.get("simulation.num_sessions", 10)  # Default 10 sessions
        )

        # Generate comprehensive performance reports
        # Creates analytics on student progress, content effectiveness, and system performance
        simulator.generate_reports()

    except KeyError as e:
        print(f"Configuration error: Missing required setting {e}")
        raise
    except Exception as e:
        print(f"Simulation failed: {e}")
        raise


if __name__ == "__main__":
    """
    Script entry point - runs the main simulation when executed directly.
    
    Uses asyncio to handle asynchronous operations like API calls to OpenAI
    and concurrent processing of multiple student sessions.
    """
    asyncio.run(main())
