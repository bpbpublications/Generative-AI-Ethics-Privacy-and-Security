from setuptools import setup, find_packages

setup(
    name="content_generator",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        'openai>=1.0.0',
        'python-dotenv>=1.0.0',
        'pyyaml>=6.0.1',
        'numpy>=1.21.0'
    ],
)