# Contributing to Personalized Learning System

We welcome contributions to the Personalized Learning System! This document provides guidelines for contributing to the project.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [How to Contribute](#how-to-contribute)
- [Pull Request Process](#pull-request-process)
- [Coding Standards](#coding-standards)
- [Testing Guidelines](#testing-guidelines)
- [Documentation](#documentation)
- [Issue Guidelines](#issue-guidelines)

## Code of Conduct

By participating in this project, you agree to abide by our Code of Conduct:

- Be respectful and inclusive
- Focus on constructive feedback
- Help others learn and grow
- Maintain professionalism in all interactions

## Getting Started

### Prerequisites

- Python 3.8 or higher
- Git
- OpenAI API key (for testing content generation features)
- Basic understanding of machine learning and educational technology concepts

### Fork and Clone

1. Fork the repository on GitHub
2. Clone your fork locally:
```bash
git clone https://github.com/yourusername/personalized-learning.git
cd personalized-learning
```

## Development Setup

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your OpenAI API key and other configuration
```

4. Run tests to ensure everything works:
```bash
python -m pytest tests/
```

## How to Contribute

### Types of Contributions

We welcome several types of contributions:

- **Bug fixes**: Fix issues in existing code
- **Feature enhancements**: Improve existing functionality
- **New features**: Add new capabilities to the system
- **Documentation**: Improve or add documentation
- **Tests**: Add or improve test coverage
- **Performance optimizations**: Make the system faster or more efficient

### Before You Start

1. Check existing issues and pull requests to avoid duplication
2. Open an issue to discuss major changes before starting work
3. Make sure you understand the project's architecture and goals

## Pull Request Process

### Creating a Pull Request

1. Create a feature branch from `main`:
```bash
git checkout -b feature/your-feature-name
```

2. Make your changes following our coding standards
3. Add tests for new functionality
4. Update documentation as needed
5. Commit your changes with clear, descriptive messages
6. Push your branch to your fork
7. Open a pull request with a clear title and description

### Pull Request Requirements

- [ ] Code follows project coding standards
- [ ] All tests pass
- [ ] New features include appropriate tests
- [ ] Documentation is updated if needed
- [ ] Commit messages are clear and descriptive
- [ ] No sensitive information (API keys, passwords) is included

### Review Process

1. Maintainers will review your pull request
2. Address any feedback or requested changes
3. Once approved, your PR will be merged

## Coding Standards

### Python Code Style

- Follow PEP 8 style guidelines
- Use type hints for function parameters and return values
- Write docstrings for all classes and functions
- Keep functions focused and reasonably sized
- Use meaningful variable and function names

### Code Structure

```python
def function_name(param: Type) -> ReturnType:
    """
    Brief description of what the function does.
    
    Args:
        param (Type): Description of parameter
        
    Returns:
        ReturnType: Description of return value
        
    Raises:
        ExceptionType: Description of when this exception is raised
    """
    # Implementation here
    return result
```

### Import Organization

```python
# Standard library imports
import os
import asyncio
from typing import Dict, List

# Third-party imports
import numpy as np
import yaml

# Local imports
from .core.student import StudentProfile
from .utils.logger import logger
```

## Testing Guidelines

### Writing Tests

- Write tests for all new functionality
- Use descriptive test names
- Test both success and failure cases
- Mock external dependencies (API calls, file operations)

### Test Structure

```python
import pytest
from unittest.mock import Mock, patch

class TestContentGenerator:
    def test_generate_content_success(self):
        """Test successful content generation."""
        # Arrange
        generator = ContentGenerator(api_key="test-key")
        student = create_test_student()
        
        # Act
        result = generator.generate_content(student, "math")
        
        # Assert
        assert result is not None
        assert "content" in result
```

### Running Tests

```bash
# Run all tests
python -m pytest

# Run with coverage
python -m pytest --cov=src tests/

# Run specific test file
python -m pytest tests/test_content_generator.py
```

## Documentation

### Code Documentation

- Write clear docstrings for all public functions and classes
- Include examples in docstrings when helpful
- Document complex algorithms and business logic
- Keep comments up-to-date with code changes

### README Updates

When adding new features:
- Update installation instructions if needed
- Add usage examples
- Update the features list
- Include any new configuration options

## Issue Guidelines

### Reporting Bugs

Include the following information:
- Clear description of the bug
- Steps to reproduce
- Expected vs actual behavior
- Environment details (Python version, OS, etc.)
- Error messages or logs

### Feature Requests

Include:
- Clear description of the proposed feature
- Use case and motivation
- Proposed implementation approach (if any)
- Examples of how it would be used

### Issue Labels

We use these labels to categorize issues:
- `bug`: Something isn't working
- `enhancement`: Improve existing feature
- `feature`: New functionality
- `documentation`: Improve docs
- `good first issue`: Good for newcomers
- `help wanted`: Need community help

## Development Workflow

### Branch Naming

- `feature/description`: For new features
- `bugfix/issue-number`: For bug fixes
- `docs/description`: For documentation updates
- `refactor/description`: For code refactoring

### Commit Messages

Use clear, descriptive commit messages:

```
Add personalized difficulty adjustment algorithm

- Implement adaptive difficulty based on student performance
- Add tests for difficulty adjustment logic
- Update documentation with new algorithm details
```

## Performance Considerations

When contributing, consider:
- **API Usage**: Minimize OpenAI API calls to reduce costs
- **Memory Efficiency**: Handle large datasets efficiently
- **Async Operations**: Use async/await for I/O bound operations
- **Caching**: Implement caching where appropriate

## Security Guidelines

- Never commit API keys, passwords, or sensitive data
- Use environment variables for configuration
- Validate all user inputs
- Follow secure coding practices
- Report security vulnerabilities privately

## Getting Help

If you need help:
- Check existing issues and documentation
- Open a discussion for general questions
- Contact maintainers for sensitive issues

## Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes for significant contributions
- GitHub contributor statistics

Thank you for contributing to the Personalized Learning System! 🎓✨