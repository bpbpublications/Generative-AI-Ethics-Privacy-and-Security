import os
import asyncio
from dotenv import load_dotenv
from src.core.student import StudentProfile, LearningStyle
from src.core.content_generator import ContentGenerator
from src.core.progress_tracker import ProgressTracker

# Function to conduct an assessment for a student on a given topic
async def conduct_assessment(content_generator, student, topic, num_questions=5):
    """
    Conduct an initial assessment with multiple questions.

    Args:
        content_generator (ContentGenerator): Instance of the content generator.
        student (StudentProfile): The student's profile data.
        topic (str): Topic to assess the student on.
        num_questions (int): Number of questions in the assessment. Default is 5.

    Returns:
        list: A list of results containing question details, difficulty levels,
              understanding ratings, and whether the question was attempted.
    """
    print(f"\nConducting assessment for {topic}...")
    results = []

    difficulty = 0.5  # Start with medium difficulty

    for i in range(num_questions):
        print(f"\nQuestion {i + 1} of {num_questions}")
        # Generate content for the question
        content = await content_generator.generate_content(
            student=student,
            topic=topic,
            difficulty=difficulty
        )

        if content:
            print("\nExercise:")
            print(content.get("exercise", "No exercise generated"))

            # Get student's answer
            answer = input("\nYour answer: ")

            # Show solution
            print("\nSolution:")
            print(content.get("solution", "No solution available"))

            # Get self-assessment of understanding (1-5)
            understanding = int(input("\nRate your understanding (1-5): "))

            # Adjust difficulty based on self-assessed understanding
            if understanding >= 4:
                difficulty = min(1.0, difficulty + 0.1)
            elif understanding <= 2:
                difficulty = max(0.1, difficulty - 0.1)

            # Store result details
            results.append({
                "question_number": i + 1,
                "difficulty": difficulty,
                "understanding": understanding,
                "attempted": bool(answer.strip()),
                "content": content
            })

    return results

# Function to generate a personalized learning plan for a student
async def generate_learning_plan(results, student):
    """
    Generate a personalized learning plan based on assessment results.

    Args:
        results (list): List of assessment results.
        student (StudentProfile): The student's profile data.

    Returns:
        dict: A dictionary containing overall understanding level, strengths, weaknesses,
              and recommended difficulty level for future sessions.
    """
    strengths = []
    weaknesses = []

    # Analyze assessment results
    for result in results:
        if result["understanding"] >= 4:
            strengths.append(result["content"]["topic"])
        elif result["understanding"] <= 2:
            weaknesses.append(result["content"]["topic"])

    # Calculate average understanding
    avg_understanding = sum(r["understanding"] for r in results) / len(results)

    return {
        "overall_level": avg_understanding,
        "strengths": list(set(strengths)),
        "weaknesses": list(set(weaknesses)),
        "recommended_difficulty": sum(r["difficulty"] for r in results) / len(results)
    }

# Main function to orchestrate the personalized learning session
async def main():
    """
    Main function to initialize components, conduct assessments, and generate learning plans.
    """
    # Load environment variables from .env file
    load_dotenv()

    # Initialize content generator with API key and model
    content_generator = ContentGenerator(
        api_key=os.getenv("OPENAI_API_KEY"),
        model="gpt-3.5-turbo"
    )

    # Initialize progress tracker
    progress_tracker = ProgressTracker()

    # Create a new student profile
    student = StudentProfile(
        id="student_1",
        name=input("Enter your name: "),
        strengths=[],
        weaknesses=[],
        learning_style=LearningStyle.VISUAL,
        current_topic="math",
        progress={},
        skill_levels={}
    )

    print(f"\nWelcome {student.name}! Let's begin your personalized learning session.")

    # Display available topics and select one
    topics = ["math", "physics", "chemistry", "biology"]
    print("\nAvailable topics:")
    for i, topic in enumerate(topics, 1):
        print(f"{i}. {topic}")

    topic_choice = int(input("\nSelect a topic (1-4): ")) - 1
    selected_topic = topics[topic_choice]

    # Conduct an initial assessment for the selected topic
    assessment_results = await conduct_assessment(
        content_generator,
        student,
        selected_topic
    )

    # Generate a learning plan based on the assessment results
    learning_plan = await generate_learning_plan(assessment_results, student)

    # Prepare session results for progress tracking
    session_results = {
        "duration": 30,  # Session duration in minutes
        "metrics": {
            "completed_exercises": len(assessment_results),
            "correct_answers": sum(1 for r in assessment_results if r["understanding"] >= 4),
            "topics_covered": [selected_topic],
            "difficulty_progression": [r["difficulty"] for r in assessment_results],
            "understanding_levels": [r["understanding"] for r in assessment_results]
        }
    }

    # Update student's progress
    progress_tracker.update_progress(student, session_results)

    # Retrieve the progress report
    progress_report = progress_tracker.get_progress_report(student.id)

    # Display session summary and recommendations
    print("\n" + "=" * 50)
    print("LEARNING SESSION SUMMARY")
    print("=" * 50)

    print("\nAssessment Results:")
    print(f"Total Questions: {len(assessment_results)}")
    print(f"Average Understanding: {learning_plan['overall_level']:.1f}/5.0")

    print("\nStrengths:")
    for strength in learning_plan['strengths']:
        print(f"- {strength}")

    print("\nAreas for Improvement:")
    for weakness in learning_plan['weaknesses']:
        print(f"- {weakness}")

    print("\nProgress Overview:")
    print(f"Overall Progress: {progress_report.get('overall_progress', 0):.1%}")

    print("\nRecommended Next Steps:")
    for rec in progress_report.get('recommendations', []):
        print(f"- {rec}")

    # Additional recommendations based on overall understanding
    print("\nAdditional Recommendations:")
    if learning_plan['overall_level'] < 3:
        print("- Review fundamental concepts")
        print("- Consider more practice with basic problems")
        print("- Try using different learning resources")
    elif learning_plan['overall_level'] < 4:
        print("- Focus on specific weak areas")
        print("- Increase practice frequency")
        print("- Consider more challenging problems")
    else:
        print("- Move on to advanced topics")
        print("- Try teaching concepts to others")
        print("- Explore related topics")

    # Option to start another session
    if input("\nWould you like to start another session? (y/n): ").lower() == 'y':
        await main()

# Entry point of the script
if __name__ == "__main__":
    asyncio.run(main())
