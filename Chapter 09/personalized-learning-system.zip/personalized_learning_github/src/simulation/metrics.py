from typing import Dict, List
import matplotlib.pyplot as plt
from ..core.student import StudentProfile


class SimulationMetrics:
    """Handles calculation and visualization of simulation metrics"""

    def __init__(self):
        self.metrics_history: Dict[str, List[float]] = {
            'average_performance': [],
            'topic_mastery': {},
            'learning_rate': []
        }

    def update_metrics(self, students: List[StudentProfile]):
        """Update metrics based on current student states"""
        avg_performance = self._calculate_average_performance(students)
        self.metrics_history['average_performance'].append(avg_performance)

        topic_mastery = self._calculate_topic_mastery(students)
        for topic, mastery in topic_mastery.items():
            if topic not in self.metrics_history['topic_mastery']:
                self.metrics_history['topic_mastery'][topic] = []
            self.metrics_history['topic_mastery'][topic].append(mastery)

    def generate_report(self, output_dir: str):
        """Generate comprehensive simulation report"""
        # Create performance graphs
        self._plot_performance_trends(output_dir)

        # Generate statistical summary
        summary = self._generate_statistical_summary()

        # Save report
        report_path = f"{output_dir}/simulation_report.html"
        self._save_html_report(summary, report_path)

    def _plot_performance_trends(self, output_dir: str):
        """Plot various performance trends"""
        plt.figure(figsize=(12, 6))
        plt.plot(self.metrics_history['average_performance'])
        plt.title('Average Student Performance Over Time')
        plt.xlabel('Session')
        plt.ylabel('Performance Score')
        plt.savefig(f"{output_dir}/performance_trend.png")
        plt.close()