import numpy as np
from typing import List, Dict
from ..core.student import StudentProfile, LearningStyle


class LearningSimulator:
    def __init__(self, num_students: int = 100):
        self.num_students = num_students
        self.students: List[StudentProfile] = []
        self.performance_history: Dict[str, List[float]] = {}

    def initialize_population(self):
        """Initialize a diverse student population with varying characteristics"""
        learning_styles = list(LearningStyle)
        topics = ["math", "reading", "science", "history"]

        for i in range(self.num_students):
            student = StudentProfile(
                id=f"student_{i}",
                name=f"Student {i}",
                strengths=np.random.choice(topics, 2, replace=False).tolist(),
                weaknesses=np.random.choice(topics, 1).tolist(),
                learning_style=np.random.choice(learning_styles),
                current_topic=np.random.choice(topics),
                progress={},
                skill_levels={topic: np.random.beta(2, 2) for topic in topics}
            )
            self.students.append(student)
            self.performance_history[student.id] = []

    async def run_simulation(self, num_sessions: int = 10):
        """Run learning simulation for multiple sessions"""
        for session in range(num_sessions):
            for student in self.students:
                # Generate and present content
                content = await self.content_generator.generate_content(
                    student=student,
                    topic=student.current_topic,
                    difficulty=self._calculate_optimal_difficulty(student)
                )

                # Simulate student response
                performance = self._simulate_student_performance(student, content)
                self.performance_history[student.id].append(performance)

                # Update student profile
                self._update_student_profile(student, performance)

            # Calculate and log session metrics
            self._log_session_metrics(session)

    def _calculate_optimal_difficulty(self, student: StudentProfile) -> float:
        """Calculate optimal content difficulty based on student's current level"""
        current_level = student.skill_levels[student.current_topic]
        return min(current_level + 0.1, 1.0)  # Slightly above current level

    def _simulate_student_performance(
            self,
            student: StudentProfile,
            content: Dict
    ) -> float:
        """Simulate student's performance on the given content"""
        base_probability = student.skill_levels[student.current_topic]

        # Adjust for student's characteristics
        if student.current_topic in student.strengths:
            base_probability += 0.1
        if student.current_topic in student.weaknesses:
            base_probability -= 0.1

        # Add some randomness
        performance = np.random.normal(base_probability, 0.1)
        return np.clip(performance, 0, 1)
