import random
from typing import Dict, List
from datetime import datetime
from ..core.student import StudentProfile
from ..core.content_generator import ContentGenerator
from ..models.assessment_models import AssessmentResult
from ..utils.logger import logger


class LearningSession:
    """Manages individual learning sessions for students"""

    def __init__(self,
                 student: StudentProfile,
                 content_generator: ContentGenerator,
                 session_duration: int = 30):
        self.student = student
        self.content_generator = content_generator
        self.session_duration = session_duration
        self.start_time = None
        self.end_time = None
        self.session_results = []

    async def start_session(self) -> Dict:
        """
        Start a learning session for the student.
        Returns session metrics.
        """
        try:
            self.start_time = datetime.now()
            logger.info(f"Starting learning session for student {self.student.name}")

            # Generate personalized content
            content = await self.content_generator.generate_content(
                student=self.student,
                topic=self.student.current_topic
            )

            if not content:
                raise ValueError("Failed to generate content")

            # Track session progress
            session_metrics = await self._conduct_session(content)

            self.end_time = datetime.now()
            duration = (self.end_time - self.start_time).seconds / 60

            return {
                "student_id": self.student.id,
                "duration": duration,
                "metrics": session_metrics
            }

        except Exception as e:
            logger.error(f"Error in learning session: {e}")
            return {"error": str(e)}

    async def _conduct_session(self, content: Dict) -> Dict:
        """
        Conduct the learning session with generated content.
        """
        metrics = {
            "completed_exercises": 0,
            "correct_answers": 0,
            "topics_covered": set(),
            "difficulty_progression": []
        }

        for exercise in content.get("exercises", []):
            result = await self._present_exercise(exercise)
            metrics["completed_exercises"] += 1
            if result.score >= 0.7:
                metrics["correct_answers"] += 1
            metrics["topics_covered"].add(exercise["topic"])
            metrics["difficulty_progression"].append(exercise["difficulty"])

        return metrics

    async def _present_exercise(self, exercise: Dict) -> AssessmentResult:
        """
        Present an exercise to the student and evaluate response.
        """
        # Simulate student interaction with exercise
        start_time = datetime.now()
        response = self._simulate_student_response(exercise)
        end_time = datetime.now()

        result = AssessmentResult(
            student_id=self.student.id,
            topic=exercise["topic"],
            score=response["score"],
            time_taken=(end_time - start_time).seconds,
            difficulty_level=exercise["difficulty"],
            mistakes=response.get("mistakes", [])
        )

        return result

    def _simulate_student_response(self, exercise: Dict) -> Dict:
        """
        Simulate student's response to an exercise based on their profile.
        """
        base_probability = self.student.skill_levels.get(exercise["topic"], 0.5)
        difficulty_factor = 1 - exercise["difficulty"]

        # Adjust probability based on student characteristics
        if exercise["topic"] in self.student.strengths:
            base_probability += 0.2
        if exercise["topic"] in self.student.weaknesses:
            base_probability -= 0.1

        # Final score calculation
        score = min(1.0, max(0.0,
                             base_probability * difficulty_factor * (1 + random.uniform(-0.1, 0.1))
                             ))

        return {
            "score": score,
            "mistakes": self._generate_simulated_mistakes(score, exercise)
        }

    def _generate_simulated_mistakes(self, score: float, exercise: Dict) -> List[str]:
        """
        Generate simulated mistakes based on performance score.
        """
        if score > 0.9:
            return []

        possible_mistakes = [
            "concept_misunderstanding",
            "calculation_error",
            "logical_error",
            "memory_recall",
            "attention_error"
        ]

        num_mistakes = int((1 - score) * 5)
        return random.sample(possible_mistakes, min(num_mistakes, len(possible_mistakes)))


