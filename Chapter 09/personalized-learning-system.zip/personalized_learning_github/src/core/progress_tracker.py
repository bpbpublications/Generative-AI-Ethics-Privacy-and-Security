from typing import Dict, List
from datetime import datetime, timedelta
from collections import defaultdict
from ..utils.logger import logger


class ProgressTracker:
    """
    Comprehensive progress tracking system for personalized learning.
    
    This class manages and analyzes student learning progress across multiple
    dimensions including topic mastery, skill development, and learning curves.
    It provides detailed analytics to help adapt content difficulty and 
    identify areas where students need additional support.
    
    Attributes:
        progress_history (Dict[str, List[Dict]]): Complete history of all student sessions
        learning_curves (Dict[str, Dict]): Time-series data showing learning progression  
        topic_mastery (Dict[str, Dict[str, float]]): Current mastery levels per topic
        skill_development (Dict[str, Dict[str, List[float]]]): Historical skill progression
    """
    
    def __init__(self):
        """
        Initialize the progress tracker with empty data structures.
        
        Sets up dictionaries to store progress data for multiple students
        across various topics and time periods.
        """
        # Complete session history for each student
        self.progress_history: Dict[str, List[Dict]] = {}
        
        # Learning curve data (scores over time) for trend analysis
        self.learning_curves: Dict[str, Dict] = {}
        
        # Current topic mastery levels (0.0 to 1.0) per student
        self.topic_mastery: Dict[str, Dict[str, float]] = {}
        
        # Historical skill development tracking
        self.skill_development: Dict[str, Dict[str, List[float]]] = {}

    def update_progress(self, student, session_results: Dict) -> None:
        """
        Update student progress based on session results.
        """
        try:
            # Validate input
            if not student or not hasattr(student, 'id'):
                logger.error("Invalid student object")
                return

            if not session_results or 'metrics' not in session_results:
                logger.error("Invalid session results format")
                return

            # Initialize student records if not exists
            if student.id not in self.progress_history:
                self.progress_history[student.id] = []
                self.topic_mastery[student.id] = {}
                self.skill_development[student.id] = defaultdict(list)

            # Add timestamp to session results
            session_entry = {
                "timestamp": datetime.now(),
                "results": session_results
            }

            # Update progress history
            self.progress_history[student.id].append(session_entry)

            # Update learning curves
            self._update_learning_curves(student.id, session_results)

            # Update topic mastery
            metrics = session_results.get('metrics', {})
            for topic in metrics.get('topics_covered', []):
                current_mastery = self.topic_mastery[student.id].get(topic, 0.0)
                topic_score = self._calculate_topic_score(session_results, topic)
                self.topic_mastery[student.id][topic] = (
                        current_mastery * 0.7 + topic_score * 0.3
                )

            logger.info(f"Updated progress for student {student.id}")

        except Exception as e:
            logger.error(f"Error updating progress: {str(e)}")

    def _calculate_topic_score(self, session_results: Dict, topic: str) -> float:
        """
        Calculate the score for a specific topic from session results.

        Args:
            session_results: Dictionary containing session metrics
            topic: The topic to calculate score for

        Returns:
            float: Score between 0 and 1
        """
        try:
            metrics = session_results.get('metrics', {})

            # If we have topic-specific scores
            if 'topic_scores' in metrics and topic in metrics['topic_scores']:
                return metrics['topic_scores'][topic]

            # Otherwise use overall performance
            completed = metrics.get('completed_exercises', 0)
            if completed > 0:
                return metrics.get('correct_answers', 0) / completed

            return 0.0

        except Exception as e:
            logger.error(f"Error calculating topic score: {str(e)}")
            return 0.0

    def _update_learning_curves(self, student_id: str, session_results: Dict) -> None:
        """
        Update learning curves with new session results.
        """
        try:
            if student_id not in self.learning_curves:
                self.learning_curves[student_id] = {
                    "timestamps": [],
                    "scores": [],
                    "topic_scores": defaultdict(list)
                }

            curves = self.learning_curves[student_id]
            timestamp = datetime.now()

            # Calculate overall score
            metrics = session_results.get('metrics', {})
            completed = metrics.get('completed_exercises', 0)
            correct = metrics.get('correct_answers', 0)

            overall_score = correct / completed if completed > 0 else 0

            # Update overall scores
            curves["timestamps"].append(timestamp)
            curves["scores"].append(overall_score)

            # Update topic-specific scores
            for topic in metrics.get('topics_covered', []):
                topic_score = self._calculate_topic_score(session_results, topic)
                curves["topic_scores"][topic].append({
                    "timestamp": timestamp,
                    "score": topic_score
                })

        except Exception as e:
            logger.error(f"Error updating learning curves: {str(e)}")

    def get_progress_report(self, student_id: str) -> Dict:
        """
        Generate a progress report for a student.
        """
        try:
            if student_id not in self.progress_history:
                return {"error": "No progress history found"}

            recent_history = [
                entry for entry in self.progress_history[student_id]
                if entry["timestamp"] > datetime.now() - timedelta(days=30)
            ]

            if not recent_history:
                return {"error": "No recent progress data"}

            # Calculate overall progress
            overall_scores = []
            for entry in recent_history:
                metrics = entry["results"].get('metrics', {})
                completed = metrics.get('completed_exercises', 0)
                if completed > 0:
                    score = metrics.get('correct_answers', 0) / completed
                    overall_scores.append(score)

            return {
                "overall_progress": sum(overall_scores) / len(overall_scores) if overall_scores else 0,
                "topic_mastery": self.topic_mastery.get(student_id, {}),
                "recent_activities": len(recent_history),
                "recommendations": self._generate_recommendations(student_id)
            }

        except Exception as e:
            logger.error(f"Error generating progress report: {str(e)}")
            return {"error": f"Error generating report: {str(e)}"}

    def _generate_recommendations(self, student_id: str) -> List[str]:
        """
        Generate learning recommendations based on progress.
        """
        recommendations = []

        # Get topic mastery
        topic_mastery = self.topic_mastery.get(student_id, {})

        # Add recommendations based on mastery levels
        for topic, mastery in topic_mastery.items():
            if mastery < 0.4:
                recommendations.append(f"Focus on improving basic concepts in {topic}")
            elif mastery < 0.7:
                recommendations.append(f"Practice more intermediate exercises in {topic}")
            else:
                recommendations.append(f"Try advanced problems in {topic}")

        return recommendations[:3]  # Return top 3 recommendations