import uuid
from dataclasses import dataclass
from typing import List, Dict
from enum import Enum

# Enum to define different learning styles for a student
class LearningStyle(Enum):
    """
    Enum representing the different learning styles.
    """
    VISUAL = "visual"        # Learns best through visual aids like diagrams and videos
    AUDITORY = "auditory"    # Learns best through listening
    KINESTHETIC = "kinesthetic"  # Learns best through hands-on activities
    TEXT = "text"            # Learns best through reading and writing

@dataclass
class StudentProfile:
    """
    Data class representing a student's profile.

    Attributes:
        id (str): Unique identifier for the student.
        name (str): Name of the student.
        strengths (List[str]): List of topics the student excels in.
        weaknesses (List[str]): List of topics the student struggles with.
        learning_style (LearningStyle): The preferred learning style of the student.
        current_topic (str): The topic the student is currently focusing on.
        progress (Dict[str, float]): A dictionary tracking the student's progress in different topics.
        skill_levels (Dict[str, float]): A dictionary representing the student's skill level in various subjects.
    """
    id: str
    name: str
    strengths: List[str]
    weaknesses: List[str]
    learning_style: LearningStyle
    current_topic: str
    progress: Dict[str, float]
    skill_levels: Dict[str, float]

    @classmethod
    def create_default(cls, name: str):
        """
        Creates a default student profile with predefined values.

        Args:
            name (str): The name of the student.

        Returns:
            StudentProfile: A new student profile with default attributes.
        """
        return cls(
            id=str(uuid.uuid4()),  # Generate a unique ID for the student
            name=name,  # Set the student's name
            strengths=[],  # Default to no strengths initially
            weaknesses=[],  # Default to no weaknesses initially
            learning_style=LearningStyle.VISUAL,  # Default to visual learning style
            current_topic="math",  # Default topic to "math"
            progress={},  # Empty progress dictionary
            skill_levels={  # Default skill levels for key subjects
                "math": 0.5,
                "reading": 0.5,
                "science": 0.5
            }
        )
