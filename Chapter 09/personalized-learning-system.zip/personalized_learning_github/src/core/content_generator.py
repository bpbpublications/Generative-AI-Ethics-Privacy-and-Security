from openai import OpenAI
import asyncio
from typing import Dict, Optional
from ..utils.logger import logger


class ContentGenerator:
    def __init__(self, api_key: str, model: str = "gpt-4"):
        self.client = OpenAI(api_key=api_key)
        self.model = model

    async def generate_content(self, student, topic: str, difficulty: float = 0.5) -> Optional[Dict]:
        """Generate personalized learning content."""
        try:
            # Adjust prompt based on difficulty
            difficulty_level = "basic" if difficulty < 0.4 else "intermediate" if difficulty < 0.7 else "advanced"

            prompt = self._create_prompt(student, topic, difficulty_level)

            response = await asyncio.to_thread(
                self.client.chat.completions.create,
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert educational content creator."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7
            )

            content = response.choices[0].message.content

            return {
                "topic": topic,
                "difficulty": difficulty,
                "difficulty_level": difficulty_level,
                "content": content,
                "exercise": self._extract_exercise(content),
                "solution": self._extract_solution(content)
            }

        except Exception as e:
            logger.error(f"Error generating content: {e}")
            return None

    def _create_prompt(self, student, topic: str, difficulty_level: str) -> str:
        """
        Create a detailed prompt for content generation based on student profile and topic.

        Args:
            student: StudentProfile object containing student information
            topic: The subject area for content generation
            difficulty_level: Current difficulty level (basic/intermediate/advanced)

        Returns:
            str: Detailed prompt for content generation
        """
        # Define topic-specific keywords and concepts
        topic_concepts = {
            "math": {
                "basic": ["arithmetic", "basic algebra", "simple equations"],
                "intermediate": ["quadratic equations", "functions", "geometry"],
                "advanced": ["calculus", "complex numbers", "trigonometry"]
            },
            "physics": {
                "basic": ["motion", "forces", "energy"],
                "intermediate": ["work", "power", "momentum"],
                "advanced": ["quantum mechanics", "relativity", "electromagnetics"]
            },
            "chemistry": {
                "basic": ["elements", "compounds", "basic reactions"],
                "intermediate": ["chemical bonding", "stoichiometry", "solutions"],
                "advanced": ["organic chemistry", "thermodynamics", "kinetics"]
            },
            "biology": {
                "basic": ["cells", "basic anatomy", "classification"],
                "intermediate": ["genetics", "evolution", "ecology"],
                "advanced": ["molecular biology", "biochemistry", "biotechnology"]
            }
        }

        # Get relevant concepts for the topic and difficulty
        concepts = topic_concepts.get(topic, {}).get(difficulty_level, [])

        # Create learning style specific instructions
        style_instructions = {
            "visual": "Include diagrams, charts, or visual representations in the explanation.",
            "auditory": "Use descriptive language and verbal analogies.",
            "kinesthetic": "Include hands-on examples or interactive elements.",
            "text": "Provide detailed written explanations and examples."
        }

        # Build the prompt
        prompt = f"""
        Create an educational exercise following these specifications:

        Subject: {topic}
        Level: {difficulty_level}
        Concepts to Cover: {', '.join(concepts)}
        Learning Style Adaptation: {style_instructions.get(student.learning_style.value, '')}

        Please structure the response as follows:

        Exercise:
        [Provide a clear, well-structured question or problem]

        Solution:
        [Provide a detailed, step-by-step solution]

        Explanation:
        [Include additional context, concepts, and learning points]

        Additional Notes:
        - Make the content engaging and interactive
        - Include real-world applications where possible
        - Provide hints or scaffolding for complex problems
        - Address common misconceptions

        Format Guidelines:
        1. Exercise should be clear and unambiguous
        2. Solution should show all steps clearly
        3. Include relevant formulas or principles
        4. Add examples if helpful
        """

        # Add difficulty-specific instructions
        if difficulty_level == "basic":
            prompt += """
            Additional Basic Level Guidelines:
            - Focus on fundamental concepts
            - Use simple language
            - Provide more guidance
            - Include confidence-building elements
            """
        elif difficulty_level == "intermediate":
            prompt += """
            Additional Intermediate Level Guidelines:
            - Combine multiple concepts
            - Include some challenging elements
            - Reduce guidance slightly
            - Encourage independent thinking
            """
        else:  # advanced
            prompt += """
            Additional Advanced Level Guidelines:
            - Integrate complex concepts
            - Challenge problem-solving abilities
            - Minimize direct guidance
            - Encourage creative solutions
            """

        # Add previous performance considerations
        if hasattr(student, 'progress') and student.progress:
            prompt += f"""
            Student Progress Considerations:
            - Previous performance in {topic}: {student.progress.get(topic, 'No data')}
            - Build upon previously mastered concepts
            - Address any identified weak areas
            """

        return prompt

    def _extract_exercise(self, content: str) -> str:
        """Extract and format the exercise from generated content."""
        try:
            if "Exercise:" in content:
                exercise = content.split("Exercise:")[1].split("Solution:")[0].strip()
                # Format the exercise
                return self._format_content(exercise)
            return content
        except Exception as e:
            logger.error(f"Error extracting exercise: {e}")
            return content

    def _extract_solution(self, content: str) -> str:
        """Extract and format the solution from generated content."""
        try:
            if "Solution:" in content:
                solution = content.split("Solution:")[1].split("Explanation:")[0].strip()
                # Format the solution
                return self._format_content(solution)
            return ""
        except Exception as e:
            logger.error(f"Error extracting solution: {e}")
            return ""

    def _format_content(self, content: str) -> str:
        """Format the content for better readability."""
        # Remove extra whitespace
        content = ' '.join(content.split())

        # Add proper line breaks for steps
        content = content.replace(". ", ".\n")

        # Format mathematical expressions
        content = self._format_math_expressions(content)

        return content

    def _format_math_expressions(self, content: str) -> str:
        """Format mathematical expressions for better readability."""
        # Replace basic math operators
        replacements = {
            'multiply': '×',
            'divide': '÷',
            'plus': '+',
            'minus': '-',
            'equals': '='
        }

        for word, symbol in replacements.items():
            content = content.replace(f" {word} ", f" {symbol} ")

        return content