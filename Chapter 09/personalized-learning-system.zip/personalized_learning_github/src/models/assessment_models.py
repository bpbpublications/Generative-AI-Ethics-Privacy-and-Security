from typing import Dict, List
import numpy as np
from dataclasses import dataclass


@dataclass
class AssessmentResult:
    """
    Data class representing the result of a student assessment.
    
    This class encapsulates all information about a student's performance
    on a specific assessment, including scoring, timing, and error tracking.
    
    Attributes:
        student_id (str): Unique identifier for the student
        topic (str): Subject area of the assessment (e.g., 'math', 'physics')
        score (float): Performance score between 0.0 and 1.0
        time_taken (float): Duration in seconds to complete the assessment
        difficulty_level (float): Difficulty level between 0.0 (easy) and 1.0 (hard)
        mistakes (List[str]): List of mistake categories made during assessment
    """
    student_id: str
    topic: str
    score: float
    time_taken: float
    difficulty_level: float
    mistakes: List[str]


class PerformanceAnalyzer:
    """
    Analyzes student performance data and provides educational insights.
    
    This class maintains a history of assessment results and provides methods
    to analyze performance trends, identify areas for improvement, and track
    student progress across different topics and difficulty levels.
    """

    def __init__(self):
        """
        Initialize the performance analyzer with an empty assessment history.
        """
        self.assessment_history: List[AssessmentResult] = []

    def add_assessment(self, result: AssessmentResult):
        """
        Add a new assessment result to the performance history.
        
        Args:
            result (AssessmentResult): The assessment result to add to history
        """
        self.assessment_history.append(result)

    def get_student_progress(self, student_id: str) -> Dict[str, float]:
        """
        Calculate a student's average progress across all topics.
        
        This method analyzes all assessments for a specific student and calculates
        the average score for each topic they have been assessed on.
        
        Args:
            student_id (str): Unique identifier for the student
            
        Returns:
            Dict[str, float]: Dictionary mapping topic names to average scores
        """
        # Filter assessments for the specific student
        student_assessments = [
            a for a in self.assessment_history
            if a.student_id == student_id
        ]

        # Group assessments by topic
        progress = {}
        for assessment in student_assessments:
            if assessment.topic not in progress:
                progress[assessment.topic] = []
            progress[assessment.topic].append(assessment.score)

        # Calculate average score for each topic
        return {
            topic: np.mean(scores)
            for topic, scores in progress.items()
        }

    def identify_improvement_areas(self, student_id: str) -> List[str]:
        """
        Identify topics where the student needs improvement.
        
        This method analyzes a student's performance and identifies topics
        where their average score is below the improvement threshold (0.7).
        
        Args:
            student_id (str): Unique identifier for the student
            
        Returns:
            List[str]: List of topic names where improvement is needed
        """
        progress = self.get_student_progress(student_id)
        return [
            topic
            for topic, score in progress.items()
            if score < 0.7  # Improvement threshold
        ]