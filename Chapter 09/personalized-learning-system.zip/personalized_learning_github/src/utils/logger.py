"""
Logging Configuration Module

This module provides centralized logging configuration for the personalized learning system.
It sets up both file and console logging with consistent formatting and manages log file
creation and rotation. The logging system is designed to support debugging, monitoring,
and analysis of the learning system's performance.

The module configures logging to write to both:
- A persistent log file for historical analysis
- Console output for real-time monitoring during development
"""

import logging
import sys
from pathlib import Path


def setup_logging(log_level: str = "INFO") -> None:
    """
    Configure comprehensive logging for the application.
    
    This function sets up a dual-output logging system that writes to both
    a log file and the console. It automatically creates the logs directory
    if it doesn't exist and configures appropriate formatting for different
    output destinations.
    
    Args:
        log_level (str): The minimum logging level to capture.
                        Options: DEBUG, INFO, WARNING, ERROR, CRITICAL
                        Default: "INFO"
                        
    Example:
        >>> setup_logging("DEBUG")  # Enable debug-level logging
        >>> setup_logging("ERROR")  # Only log errors and above
        
    The logging format includes:
        - Timestamp for chronological analysis
        - Logger name for source identification
        - Log level for priority filtering
        - Actual message content
        
    Output destinations:
        1. File: logs/app.log (persistent storage)
        2. Console: stdout (real-time monitoring)
    """
    # Create logs directory if it doesn't exist
    # This ensures log files can be written without directory errors
    log_dir = Path(__file__).parent.parent.parent / "logs"
    log_dir.mkdir(exist_ok=True)

    # Configure the root logger with dual output handlers
    logging.basicConfig(
        level=getattr(logging, log_level),  # Convert string level to logging constant
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            # File handler for persistent logging
            logging.FileHandler(log_dir / "app.log"),
            # Console handler for real-time output
            logging.StreamHandler(sys.stdout)
        ]
    )


# Create a module-level logger for use throughout the application
# This logger inherits the configuration set by setup_logging()
logger = logging.getLogger(__name__)