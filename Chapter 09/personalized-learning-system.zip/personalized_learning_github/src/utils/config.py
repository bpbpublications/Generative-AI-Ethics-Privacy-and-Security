"""
Configuration Management Module

This module provides utilities for loading and managing system configuration
from YAML files. It supports hierarchical configuration access using dot notation
and provides fallback default values for missing configuration keys.

The configuration system is designed to be flexible and environment-aware,
supporting different settings for development, testing, and production environments.
"""

import yaml
from pathlib import Path
from typing import Dict, Any


def load_config() -> Dict[str, Any]:
    """
    Load system configuration from the main config.yaml file.
    
    Reads the configuration file from the config directory relative to this module
    and returns the parsed YAML content as a dictionary. This function handles
    the file path resolution automatically.
    
    Returns:
        Dict[str, Any]: Parsed configuration data from YAML file
        
    Raises:
        FileNotFoundError: If config.yaml file is not found
        yaml.YAMLError: If the YAML file contains invalid syntax
        
    Example:
        >>> config = load_config()
        >>> print(config['content_generation']['default_model'])
        'gpt-3.5-turbo'
    """
    # Build path to config file relative to this module's location
    config_path = Path(__file__).parent.parent.parent / "config" / "config.yaml"
    
    # Load and parse YAML configuration file
    with open(config_path) as f:
        return yaml.safe_load(f)


class Config:
    """
    Advanced configuration management class with dot-notation access.
    
    This class provides a convenient interface for accessing nested configuration
    values using dot notation (e.g., 'database.host' instead of config['database']['host']).
    It automatically loads the configuration on initialization and provides
    fallback default values for missing keys.
    
    Attributes:
        config (Dict[str, Any]): The loaded configuration dictionary
        
    Example:
        >>> config = Config()
        >>> model_name = config.get('content_generation.default_model', 'gpt-4')
        >>> timeout = config.get('api.timeout', 30)
    """
    
    def __init__(self):
        """
        Initialize the configuration manager by loading the config file.
        
        Automatically loads the system configuration from the YAML file
        and stores it for efficient access throughout the application lifecycle.
        """
        self.config = load_config()

    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a configuration value using dot notation with optional default.
        
        This method allows accessing nested configuration values using a simple
        dot-separated string format. If any key in the path doesn't exist,
        the default value is returned instead of raising an exception.
        
        Args:
            key (str): Dot-separated path to the configuration value 
                      (e.g., 'content_generation.temperature')
            default (Any, optional): Default value to return if key is not found
            
        Returns:
            Any: The configuration value or the default value if key doesn't exist
            
        Example:
            >>> config = Config()
            >>> temperature = config.get('content_generation.temperature', 0.7)
            >>> num_students = config.get('simulation.num_students', 100)
        """
        # Split the key into individual components
        keys = key.split('.')
        value = self.config
        
        # Navigate through the nested dictionary structure
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                # If we encounter a non-dict value before reaching the end,
                # return the default value
                return default
                
        # Return the found value, or default if value is None
        return value if value is not None else default