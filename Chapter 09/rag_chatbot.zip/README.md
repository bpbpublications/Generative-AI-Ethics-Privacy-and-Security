# WikiChat - RAG-Powered Chatbot

A Retrieval-Augmented Generation (RAG) chatbot that allows users to ask questions about any Wikipedia topic. The system retrieves relevant information from Wikipedia articles, processes it through a vector database, and uses OpenAI's language models to provide accurate, context-aware responses.

## Features

- **Dynamic Topic Loading**: Load information about any Wikipedia topic
- **Intelligent Q&A**: Ask follow-up questions with conversation memory
- **Vector Search**: Efficient similarity search using ChromaDB
- **Clean Interface**: Simple, intuitive Streamlit web interface
- **Persistent Storage**: Vector databases are saved locally for reuse
- **Educational Focus**: Well-documented code for learning purposes

## How It Works

1. **Content Retrieval**: Fetches Wikipedia articles related to your topic
2. **Text Processing**: Splits content into manageable chunks with overlap
3. **Vector Storage**: Converts text chunks to embeddings using OpenAI
4. **Question Processing**: Uses similarity search to find relevant context
5. **Answer Generation**: Generates responses using retrieved context

## Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Wikipedia     │───▶│  Text Processor  │───▶│  Vector Store   │
│   Retriever     │    │  (Chunking)      │    │  (ChromaDB)     │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                                        │
┌─────────────────┐    ┌──────────────────┐            │
│   Streamlit     │◀───│   QA Chain       │◀───────────┘
│   Frontend      │    │  (LangChain)     │
└─────────────────┘    └──────────────────┘
```

## Installation

### Prerequisites

- Python 3.8 or higher
- OpenAI API key

### Setup

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd rag_chatbot
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up environment variables**:
   Create a `.env` file in the project root:
   ```
   OPENAI_API_KEY=your_openai_api_key_here
   ```

4. **Run the application**:
   ```bash
   streamlit run run.py
   ```

## Usage

1. **Start the Application**: Run `streamlit run run.py`
2. **Load a Topic**: Enter a topic in the sidebar and click "Load Topic"
3. **Ask Questions**: Use the chat interface to ask questions about the loaded topic
4. **Follow-up Questions**: The system maintains conversation context for natural dialogue

### Example Session

```
User: [Loads topic: "Machine Learning"]
System: Loaded 15 chunks of information

User: "What is machine learning?"
Assistant: "Machine learning is a method of data analysis that automates 
analytical model building. It is a branch of artificial intelligence 
based on the idea that systems can learn from data..."

User: "What are the main types?"
Assistant: "The main types of machine learning include supervised learning, 
unsupervised learning, and reinforcement learning..."
```

## Configuration

Key settings can be modified in `src/config/settings.py`:

- `WIKI_LANGUAGE`: Wikipedia language (default: "en")
- `MAX_WIKI_PAGES`: Number of Wikipedia pages to retrieve (default: 2)
- `CHUNK_SIZE`: Size of text chunks in characters (default: 1000)
- `CHUNK_OVERLAP`: Overlap between chunks (default: 200)
- `VECTOR_STORE_PATH`: Local storage path for vector database

## Project Structure

```
rag_chatbot/
├── src/
│   ├── config/
│   │   └── settings.py          # Configuration settings
│   ├── core/
│   │   ├── retriever.py         # Wikipedia content retrieval
│   │   └── processor.py         # Text chunking and processing
│   ├── database/
│   │   └── vector_store.py      # Vector database operations
│   ├── frontend/
│   │   └── app.py              # Streamlit web interface
│   ├── models/
│   │   └── qa_chain.py         # Q&A chain implementation
│   └── utils/
│       └── helpers.py          # Utility functions
├── data/
│   └── vector_store/           # Local vector database storage
├── run.py                      # Application entry point
├── requirements.txt            # Python dependencies
└── README.md                   # Project documentation
```

## Dependencies

- **streamlit**: Web interface framework
- **langchain**: LLM application framework
- **langchain-openai**: OpenAI integration
- **chromadb**: Vector database
- **wikipedia-api**: Wikipedia content access
- **openai**: OpenAI API client
- **python-dotenv**: Environment variable management

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/new-feature`)
3. Commit your changes (`git commit -am 'Add new feature'`)
4. Push to the branch (`git push origin feature/new-feature`)
5. Create a Pull Request

### Development Guidelines

- Follow PEP 8 style guidelines
- Add docstrings to all functions and classes
- Include type hints where appropriate
- Write unit tests for new functionality
- Update documentation for significant changes

## Educational Purpose

This project is designed to be educational and demonstrates:

- **RAG Architecture**: How to build retrieval-augmented generation systems
- **Vector Databases**: Practical use of embeddings and similarity search
- **LangChain**: Integration with LLM frameworks
- **Streamlit**: Rapid web application development
- **API Integration**: Working with external APIs (OpenAI, Wikipedia)

## Limitations

- Requires internet connection for Wikipedia and OpenAI API access
- Limited to information available on Wikipedia
- Response quality depends on the relevance of retrieved context
- Vector storage grows with the number of topics loaded

## License

This project is open source and available under the [MIT License](LICENSE).

## Troubleshooting

### Common Issues

1. **"Please load a topic first!"**
   - Make sure to enter a topic in the sidebar and click "Load Topic"

2. **API Key Errors**
   - Verify your OpenAI API key is correctly set in the `.env` file
   - Ensure you have sufficient API credits

3. **Wikipedia Retrieval Errors**
   - Some topics may have disambiguation issues
   - Try using more specific topic names

4. **Vector Store Issues**
   - Delete the `data/vector_store` directory to reset the database
   - Ensure you have write permissions in the project directory

### Getting Help

If you encounter issues:
1. Check the console output for error messages
2. Verify all dependencies are installed correctly
3. Ensure your `.env` file is properly configured
4. Try with a simple topic first (e.g., "Python programming")

## Acknowledgments

- Built using [LangChain](https://github.com/langchain-ai/langchain)
- Web interface powered by [Streamlit](https://streamlit.io/)
- Vector storage via [ChromaDB](https://www.trychroma.com/)
- Wikipedia content through [wikipedia-api](https://pypi.org/project/wikipedia-api/)