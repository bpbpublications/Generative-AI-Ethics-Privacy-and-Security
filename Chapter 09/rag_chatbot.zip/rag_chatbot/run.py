"""
Entry point for the RAG Chatbot application.

This script serves as the main launcher for the WikiChat RAG-powered chatbot.
It imports and runs the Streamlit-based web interface, making it easy to
start the application with a simple Python command.

To run the application:
    python run.py

Prerequisites:
    - OpenAI API key set in .env file
    - All dependencies installed (see requirements.txt)
    - Python 3.8+ environment

The application will start a local Streamlit server accessible via web browser.
"""

from src.frontend.app import main

if __name__ == "__main__":
    # Launch the Streamlit web application
    main()