from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from src.config.settings import VECTOR_STORE_PATH
import os


class VectorStore:
    def __init__(self):
        self.embeddings = OpenAIEmbeddings()
        self.persist_directory = VECTOR_STORE_PATH

    def create_store(self, texts: list) -> Chroma:
        """
        Create a new vector store from the given texts
        """
        return Chroma.from_texts(
            texts,
            self.embeddings,
            persist_directory=self.persist_directory
        )

    def load_store(self) -> Chroma:
        """
        Load an existing vector store from disk
        """
        if not os.path.exists(self.persist_directory):
            raise FileNotFoundError("No vector store found at specified location")

        return Chroma(
            persist_directory=self.persist_directory,
            embedding_function=self.embeddings
        )

    def persist_store(self, store: Chroma):
        """
        Persist the vector store to disk
        """
        store.persist()

    def add_texts(self, store: Chroma, texts: list):
        """
        Add new texts to an existing vector store
        """
        store.add_texts(texts)
        self.persist_store(store)

    def search(self, store: Chroma, query: str, k: int = 4):
        """
        Search the vector store for similar documents
        """
        return store.similarity_search(query, k=k)

    def delete_store(self):
        """
        Delete the vector store from disk
        """
        if os.path.exists(self.persist_directory):
            import shutil
            shutil.rmtree(self.persist_directory)

    def get_collection_stats(self, store: Chroma):
        """
        Get statistics about the vector store
        """
        return {
            "total_documents": len(store.get()),
            "embedding_dimension": self.embeddings.embedding_dim,
        }


class VectorStoreManager:
    """
    A context manager for vector store operations
    """

    def __init__(self, vector_store: VectorStore):
        self.vector_store = vector_store
        self.store = None

    def __enter__(self):
        try:
            self.store = self.vector_store.load_store()
        except FileNotFoundError:
            self.store = None
        return self.store

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.store is not None:
            self.vector_store.persist_store(self.store)