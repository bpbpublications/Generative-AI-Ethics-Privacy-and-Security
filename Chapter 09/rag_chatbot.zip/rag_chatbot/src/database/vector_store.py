from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from src.config.settings import VECTOR_STORE_PATH
import os
import logging
from typing import List, Dict, Optional

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class VectorStore:
    def __init__(self, persist_directory: str = VECTOR_STORE_PATH):
        """
        Initialize vector store with ChromaDB backend

        Args:
            persist_directory: Directory to persist vector store data
        """
        self.embeddings = OpenAIEmbeddings()
        self.persist_directory = persist_directory
        # OpenAI's ada-002 model has 1536 dimensions
        self.embedding_dimension = 1536

    def create_store(self, texts: list) -> Chroma:
        """
        Create a new vector store from the given texts

        Args:
            texts: List of text documents to store

        Returns:
            Chroma vector store instance
        """
        try:
            store = Chroma.from_texts(
                texts,
                self.embeddings,
                persist_directory=self.persist_directory
            )
            logger.info(f"Created vector store with {len(texts)} documents")
            return store
        except Exception as e:
            logger.error(f"Error creating vector store: {str(e)}")
            raise

    def load_store(self) -> Chroma:
        """
        Load an existing vector store from disk

        Returns:
            Chroma vector store instance

        Raises:
            FileNotFoundError: If no vector store exists at specified location
        """
        if not os.path.exists(self.persist_directory):
            logger.error(f"No vector store found at {self.persist_directory}")
            raise FileNotFoundError("No vector store found at specified location")

        try:
            store = Chroma(
                persist_directory=self.persist_directory,
                embedding_function=self.embeddings
            )
            logger.info("Successfully loaded vector store from disk")
            return store
        except Exception as e:
            logger.error(f"Error loading vector store: {str(e)}")
            raise

    def persist_store(self, store: Chroma):
        """
        Persist the vector store to disk

        Args:
            store: Chroma vector store instance to persist
        """
        try:
            store.persist()
            logger.info(f"Vector store persisted to {self.persist_directory}")
        except Exception as e:
            logger.error(f"Error persisting vector store: {str(e)}")
            raise

    def add_texts(self, store: Chroma, texts: list):
        """
        Add new texts to an existing vector store

        Args:
            store: Existing Chroma vector store
            texts: List of new texts to add
        """
        try:
            store.add_texts(texts)
            self.persist_store(store)
            logger.info(f"Added {len(texts)} new documents to vector store")
        except Exception as e:
            logger.error(f"Error adding texts to vector store: {str(e)}")
            raise

    def search(self, store: Chroma, query: str, k: int = 4):
        """
        Search the vector store for similar documents

        Args:
            store: Chroma vector store to search
            query: Search query string
            k: Number of results to return

        Returns:
            List of similar documents
        """
        try:
            results = store.similarity_search(query, k=k)
            logger.info(f"Found {len(results)} similar documents for query")
            return results
        except Exception as e:
            logger.error(f"Error searching vector store: {str(e)}")
            raise

    def delete_store(self):
        """
        Delete the vector store from disk
        """
        try:
            if os.path.exists(self.persist_directory):
                import shutil
                shutil.rmtree(self.persist_directory)
                logger.info(f"Deleted vector store at {self.persist_directory}")
        except Exception as e:
            logger.error(f"Error deleting vector store: {str(e)}")
            raise

    def get_collection_stats(self, store: Chroma) -> Dict:
        """
        Get statistics about the vector store

        Args:
            store: Chroma vector store instance

        Returns:
            Dictionary containing vector store statistics
        """
        try:
            stats = {
                "total_documents": len(store.get()) if store else 0,
                "embedding_dimension": self.embedding_dimension,
                "persist_directory": self.persist_directory
            }
            logger.info(f"Vector store stats: {stats}")
            return stats
        except Exception as e:
            logger.error(f"Error getting collection stats: {str(e)}")
            raise


class VectorStoreManager:
    """
    A context manager for vector store operations
    """

    def __init__(self, vector_store: VectorStore):
        self.vector_store = vector_store
        self.store = None

    def __enter__(self):
        try:
            self.store = self.vector_store.load_store()
        except FileNotFoundError:
            logger.warning("No existing vector store found, returning None")
            self.store = None
        return self.store

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.store is not None:
            try:
                self.vector_store.persist_store(self.store)
            except Exception as e:
                logger.error(f"Error persisting vector store on exit: {str(e)}")
                raise