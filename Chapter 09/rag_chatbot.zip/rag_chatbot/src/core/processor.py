from langchain.text_splitter import CharacterTextSplitter
from src.config.settings import CHUNK_SIZE, CHUNK_OVERLAP


class TextProcessor:
    """
    A utility class for processing and chunking text documents for vector storage.
    
    This class is responsible for breaking down large text documents (like Wikipedia articles)
    into smaller, manageable chunks that can be effectively processed by embedding models
    and stored in vector databases.
    
    The chunking strategy used here ensures that:
    1. Each chunk is small enough to fit within embedding model limits
    2. Chunks have some overlap to maintain context continuity
    3. Text is split at natural boundaries (newlines) when possible
    """
    
    @staticmethod
    def split_text(text: str) -> list:
        """
        Split a large text document into smaller chunks for vector storage.
        
        This method uses LangChain's CharacterTextSplitter to break down text while
        maintaining semantic coherence and ensuring chunks are appropriately sized
        for embedding generation.
        
        Args:
            text (str): The input text to be chunked (typically Wikipedia content)
            
        Returns:
            list: A list of text chunks, each of maximum size CHUNK_SIZE characters
            
        Note:
            - Chunks will have CHUNK_OVERLAP characters of overlap to maintain context
            - The splitter prefers to split on newlines to maintain semantic boundaries
            - Each chunk will be converted to embeddings and stored in the vector database
        """
        # Initialize the text splitter with configuration parameters
        text_splitter = CharacterTextSplitter(
            separator="\n",           # Prefer splitting on newlines for better coherence
            chunk_size=CHUNK_SIZE,    # Maximum size of each chunk (configured in settings)
            chunk_overlap=CHUNK_OVERLAP,  # Overlap between chunks to maintain context
            length_function=len       # Use character count for measuring chunk size
        )
        
        # Split the text and return the resulting chunks
        return text_splitter.split_text(text)