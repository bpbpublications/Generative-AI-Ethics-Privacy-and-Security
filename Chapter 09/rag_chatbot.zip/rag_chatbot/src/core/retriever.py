import wikipedia
from typing import List
from src.config.settings import WIKI_LANGUAGE, MAX_WIKI_PAGES


class WikipediaRetriever:
    """
    A class responsible for retrieving content from Wikipedia articles.
    
    This component is the data source for the RAG (Retrieval-Augmented Generation) system,
    fetching relevant Wikipedia articles based on user queries to provide context for the chatbot.
    
    Attributes:
        language: The language setting for Wikipedia searches (set from config)
    """
    
    def __init__(self):
        """
        Initialize the Wikipedia retriever with the configured language setting.
        
        The language setting determines which Wikipedia language edition will be searched.
        """
        wikipedia.set_lang(WIKI_LANGUAGE)

    def get_wiki_data(self, query: str, num_pages: int = MAX_WIKI_PAGES) -> str:
        """
        Retrieve Wikipedia content for a given search query.
        
        This method performs the following steps:
        1. Search Wikipedia for articles matching the query
        2. Retrieve the full content of up to 'num_pages' articles
        3. Concatenate all article content into a single text string
        
        Args:
            query (str): The search term or topic to look up on Wikipedia
            num_pages (int): Maximum number of Wikipedia pages to retrieve (default from config)
            
        Returns:
            str: Combined content from all retrieved Wikipedia articles
            
        Note:
            - If a page cannot be retrieved due to disambiguation or other issues,
              it will be skipped and an error message will be printed
            - The returned text will be used as source material for the vector database
        """
        # Search Wikipedia for articles matching the query
        # This returns a list of article titles ranked by relevance
        search_results = wikipedia.search(query)
        text_data = []

        # Process only the top 'num_pages' results to limit data volume
        for title in search_results[:num_pages]:
            try:
                # Fetch the full Wikipedia page content
                page = wikipedia.page(title)
                text_data.append(page.content)
            except Exception as e:
                # Handle cases where pages might be ambiguous or unavailable
                # Common issues include disambiguation pages or network errors
                print(f"Error retrieving page {title}: {str(e)}")
                continue

        # Combine all article content into a single text string
        # This will be processed into chunks for the vector database
        return " ".join(text_data)