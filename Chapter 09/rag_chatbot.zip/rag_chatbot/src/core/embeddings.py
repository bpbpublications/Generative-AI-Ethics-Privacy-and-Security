from langchain_openai import OpenAIEmbeddings
from typing import List, Dict, Optional
from datetime import datetime
import logging
import asyncio
from collections import OrderedDict
import numpy as np
import json
from dataclasses import dataclass
from threading import Lock
from chromadb.config import Settings
import chromadb

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class EmbeddingMetrics:
    """Data class for embedding metrics"""
    dimension: int
    variance: float
    mean_magnitude: float
    outliers: List[int]
    timestamp: datetime


class LRUCache:
    """Least Recently Used Cache for embeddings"""

    def __init__(self, maxsize: int = 10000):
        self.cache = OrderedDict()
        self.maxsize = maxsize
        self._lock = Lock()

    def get(self, key: str) -> Optional[List[float]]:
        with self._lock:
            if key in self.cache:
                self.cache.move_to_end(key)
                return self.cache[key]
        return None

    def put(self, key: str, value: List[float]) -> None:
        with self._lock:
            if key in self.cache:
                self.cache.move_to_end(key)
            else:
                if len(self.cache) >= self.maxsize:
                    self.cache.popitem(last=False)
            self.cache[key] = value


class EmbeddingsManager:
    """Main class for managing embeddings with ChromaDB"""

    def __init__(self, api_key: Optional[str] = None, persist_directory: str = "data/vector_store"):
        """
        Initialize the embeddings manager

        Args:
            api_key: OpenAI API key (optional if set in environment)
            persist_directory: Directory to persist ChromaDB data
        """
        self.embeddings = OpenAIEmbeddings(openai_api_key=api_key)
        self.cache = LRUCache()
        self.metrics_history: List[EmbeddingMetrics] = []
        self.persist_directory = persist_directory

        # Initialize ChromaDB
        self.chroma_client = chromadb.PersistentClient(path=persist_directory)
        self.collection = self.chroma_client.create_collection(
            name="embeddings_collection",
            metadata={"hnsw:space": "cosine"}
        )

    async def create_embeddings(self, texts: List[str], use_cache: bool = True) -> List[List[float]]:
        """
        Create embeddings for given texts

        Args:
            texts: List of texts to embed
            use_cache: Whether to use cache for already computed embeddings

        Returns:
            List of embedding vectors
        """
        try:
            results = []
            texts_to_process = []
            indices_to_process = []

            # Check cache first if enabled
            if use_cache:
                for i, text in enumerate(texts):
                    cached = self.cache.get(text)
                    if cached is not None:
                        results.append(cached)
                    else:
                        texts_to_process.append(text)
                        indices_to_process.append(i)
            else:
                texts_to_process = texts
                indices_to_process = list(range(len(texts)))

            if texts_to_process:
                # Process in batches with rate limiting
                new_embeddings = await self._process_with_rate_limiting(texts_to_process)

                # Update cache and results
                for text, embedding in zip(texts_to_process, new_embeddings):
                    self.cache.put(text, embedding)

                # Merge cached and new results
                if use_cache:
                    for idx, embedding in zip(indices_to_process, new_embeddings):
                        results.insert(idx, embedding)
                else:
                    results = new_embeddings

            # Monitor quality
            if results:
                self._monitor_quality(results)

            return results

        except Exception as e:
            logger.error(f"Error creating embeddings: {str(e)}")
            raise

    async def _process_with_rate_limiting(self, texts: List[str], batch_size: int = 100) -> List[List[float]]:
        """Process texts in batches with rate limiting"""
        all_embeddings = []

        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            try:
                embeddings = await self.embeddings.aembed_documents(batch)
                all_embeddings.extend(embeddings)
                await asyncio.sleep(0.1)  # Rate limiting
            except Exception as e:
                logger.error(f"Error processing batch: {str(e)}")
                raise

        return all_embeddings

    def _monitor_quality(self, embeddings: List[List[float]]) -> EmbeddingMetrics:
        """Monitor embedding quality metrics"""
        embeddings_array = np.array(embeddings)
        magnitudes = np.linalg.norm(embeddings_array, axis=1)

        metrics = EmbeddingMetrics(
            dimension=len(embeddings[0]),
            variance=np.var(embeddings_array),
            mean_magnitude=np.mean(magnitudes),
            outliers=self._detect_outliers(magnitudes),
            timestamp=datetime.now()
        )

        self.metrics_history.append(metrics)
        return metrics

    def _detect_outliers(self, magnitudes: np.ndarray, threshold: float = 2.0) -> List[int]:
        """Detect outliers in embedding magnitudes"""
        mean_mag = np.mean(magnitudes)
        std_mag = np.std(magnitudes)
        return [i for i, mag in enumerate(magnitudes)
                if abs(mag - mean_mag) > threshold * std_mag]

    async def add_to_chroma(self, texts: List[str], metadata: Optional[List[dict]] = None):
        """Add documents to ChromaDB"""
        try:
            embeddings = await self.create_embeddings(texts)

            # Prepare IDs and metadata
            ids = [f"doc_{i}" for i in range(len(texts))]
            if metadata is None:
                metadata = [{"source": "text"} for _ in texts]

            # Add to ChromaDB
            self.collection.add(
                embeddings=embeddings,
                documents=texts,
                metadatas=metadata,
                ids=ids
            )

            return ids

        except Exception as e:
            logger.error(f"Error adding to ChromaDB: {str(e)}")
            raise

    async def similarity_search(self, query: str, k: int = 5) -> List[Dict]:
        """
        Perform similarity search using ChromaDB

        Args:
            query: Query text
            k: Number of results to return

        Returns:
            List of similar documents with scores
        """
        try:
            # Get query embedding
            query_embedding = await self.create_embeddings([query])

            # Search in ChromaDB
            results = self.collection.query(
                query_embeddings=query_embedding,
                n_results=k
            )

            # Format results
            formatted_results = []
            for i in range(len(results['documents'][0])):
                formatted_results.append({
                    'text': results['documents'][0][i],
                    'metadata': results['metadatas'][0][i],
                    'id': results['ids'][0][i],
                    'distance': results['distances'][0][i] if 'distances' in results else None,
                    'score': 1 / (1 + (results['distances'][0][i] if 'distances' in results else 0))
                })

            return formatted_results

        except Exception as e:
            logger.error(f"Error performing similarity search: {str(e)}")
            raise

    def get_quality_metrics(self) -> List[EmbeddingMetrics]:
        """Get historical quality metrics"""
        return self.metrics_history

    def save_state(self, filepath: str):
        """Save embeddings manager state"""
        data = {
            'cache': dict(self.cache.cache),
            'metrics_history': [
                {
                    'dimension': m.dimension,
                    'variance': m.variance,
                    'mean_magnitude': m.mean_magnitude,
                    'outliers': m.outliers,
                    'timestamp': m.timestamp.isoformat()
                }
                for m in self.metrics_history
            ]
        }

        try:
            with open(filepath, 'w') as f:
                json.dump(data, f)
            logger.info(f"State saved to {filepath}")
        except Exception as e:
            logger.error(f"Error saving state: {str(e)}")
            raise

    def load_state(self, filepath: str):
        """Load embeddings manager state"""
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)

            # Restore cache
            self.cache = LRUCache(maxsize=len(data['cache']))
            for k, v in data['cache'].items():
                self.cache.put(k, v)

            # Restore metrics history
            self.metrics_history = [
                EmbeddingMetrics(
                    dimension=m['dimension'],
                    variance=m['variance'],
                    mean_magnitude=m['mean_magnitude'],
                    outliers=m['outliers'],
                    timestamp=datetime.fromisoformat(m['timestamp'])
                )
                for m in data['metrics_history']
            ]

            logger.info(f"State loaded from {filepath}")
        except Exception as e:
            logger.error(f"Error loading state: {str(e)}")
            raise

    async def batch_process_documents(self, documents: List[str], batch_size: int = 100) -> Dict:
        """
        Process large batches of documents with progress tracking

        Args:
            documents: List of documents to process
            batch_size: Size of each batch

        Returns:
            Dictionary containing processing statistics
        """
        total_documents = len(documents)
        processed = 0
        failed = 0
        start_time = datetime.now()

        try:
            for i in range(0, total_documents, batch_size):
                batch = documents[i:i + batch_size]
                try:
                    # Add batch to ChromaDB
                    await self.add_to_chroma(batch)
                    processed += len(batch)
                except Exception as e:
                    logger.error(f"Error processing batch {i // batch_size}: {str(e)}")
                    failed += len(batch)

                # Log progress
                progress = (i + len(batch)) / total_documents * 100
                logger.info(f"Progress: {progress:.2f}% ({processed} processed, {failed} failed)")

            return {
                'total': total_documents,
                'processed': processed,
                'failed': failed,
                'processing_time': (datetime.now() - start_time).total_seconds(),
                'collection_name': self.collection.name,
                'persist_directory': self.persist_directory
            }

        except Exception as e:
            logger.error(f"Error in batch processing: {str(e)}")
            raise

    def clear_cache(self):
        """Clear the embeddings cache"""
        self.cache = LRUCache()
        logger.info("Embeddings cache cleared")

    def get_statistics(self) -> Dict:
        """Get general statistics about the embeddings manager"""
        try:
            collection_stats = self.collection.count()
            return {
                'cache_size': len(self.cache.cache),
                'documents_count': collection_stats,
                'metrics_history_length': len(self.metrics_history),
                'collection_name': self.collection.name,
                'persist_directory': self.persist_directory
            }
        except Exception as e:
            logger.error(f"Error getting statistics: {str(e)}")
            raise

    def reset_collection(self):
        """Reset the ChromaDB collection"""
        try:
            self.chroma_client.delete_collection(name=self.collection.name)
            self.collection = self.chroma_client.create_collection(
                name="embeddings_collection",
                metadata={"hnsw:space": "cosine"}
            )
            self.clear_cache()
            logger.info("Collection reset successfully")
        except Exception as e:
            logger.error(f"Error resetting collection: {str(e)}")
            raise