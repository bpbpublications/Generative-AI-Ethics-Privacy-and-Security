from langchain_openai import OpenAI
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory


class QAChain:
    """
    A class responsible for creating and managing the Question-Answering chain.
    
    This class combines a language model (LLM) with a vector store retriever and conversation
    memory to create a complete RAG (Retrieval-Augmented Generation) system. The system can:
    
    1. Retrieve relevant context from the vector database based on user questions
    2. Generate answers using the retrieved context and conversation history
    3. Maintain conversation memory for follow-up questions and context
    
    The QAChain is the core component that ties together all parts of the RAG system.
    """
    
    @staticmethod
    def create_chain(vectorstore):
        """
        Create a conversational retrieval chain for question-answering.
        
        This method sets up a complete RAG pipeline by combining:
        - An OpenAI language model for text generation
        - A vector store retriever for finding relevant context
        - Conversation memory for maintaining dialogue history
        
        Args:
            vectorstore: A vector store instance (ChromaDB) containing embedded text chunks
            
        Returns:
            ConversationalRetrievalChain: A fully configured chain ready for Q&A
            
        Raises:
            Exception: If there's an error creating any component of the chain
            
        Note:
            - Temperature is set to 0 for consistent, factual responses
            - Memory stores the entire conversation for context-aware responses
            - The retriever will automatically find relevant chunks for each question
        """
        try:
            # Initialize the language model with zero temperature for deterministic responses
            # Lower temperature = more focused and consistent answers
            # Higher temperature = more creative but potentially less accurate answers
            llm = OpenAI(temperature=0)
            
            # Set up conversation memory to maintain dialogue context
            # This allows the system to understand follow-up questions and references
            memory = ConversationBufferMemory(
                memory_key="chat_history",    # Key used to store conversation history
                return_messages=True          # Return structured message objects
            )

            # Create the conversational retrieval chain
            # This combines the LLM, retriever, and memory into a complete RAG system
            chain = ConversationalRetrievalChain.from_llm(
                llm=llm,                          # Language model for generating responses
                retriever=vectorstore.as_retriever(),  # Vector store retriever for context
                memory=memory                     # Conversation memory for dialogue continuity
            )

            return chain

        except Exception as e:
            # Provide detailed error information for debugging
            raise Exception(f"Error creating QA chain: {str(e)}")