import streamlit as st
from src.core.retriever import WikipediaRetriever
from src.core.processor import TextProcessor
from src.models.qa_chain import QAChain
from src.database.vector_store import VectorStore


class ChatbotUI:
    def __init__(self):
        self.retriever = WikipediaRetriever()
        self.processor = TextProcessor()
        self.vector_store = VectorStore()

    def initialize_session_state(self):
        if "messages" not in st.session_state:
            st.session_state.messages = []
        if "qa_chain" not in st.session_state:
            st.session_state.qa_chain = None

    def run(self):
        st.title("WikiChat - RAG-powered Chatbot")
        self.initialize_session_state()

        # Sidebar
        with st.sidebar:
            self.handle_topic_input()

        # Chat interface
        self.display_chat_messages()
        self.handle_user_input()

    def handle_topic_input(self):
        topic = st.text_input("Enter a topic to learn about:")
        if st.button("Load Topic"):
            with st.spinner("Loading topic information..."):
                wiki_data = self.retriever.get_wiki_data(topic)
                chunks = self.processor.split_text(wiki_data)
                vectorstore = self.vector_store.create_store(chunks)
                st.session_state.qa_chain = QAChain.create_chain(vectorstore)
                st.success(f"Loaded information about {topic}")

    def display_chat_messages(self):
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])

    def handle_user_input(self):
        if prompt := st.chat_input("Ask a question about the topic"):
            if st.session_state.qa_chain is None:
                st.error("Please load a topic first!")
                return

            self.add_message("user", prompt)
            response = st.session_state.qa_chain({"question": prompt})
            self.add_message("assistant", response["answer"])

    def add_message(self, role, content):
        st.session_state.messages.append({"role": role, "content": content})
        with st.chat_message(role):
            st.markdown(content)


def main():
    chatbot = ChatbotUI()
    chatbot.run()


if __name__ == "__main__":
    main()