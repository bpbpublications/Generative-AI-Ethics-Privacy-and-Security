"""
Streamlit-based web interface for the RAG (Retrieval-Augmented Generation) chatbot.

This module provides a user-friendly web interface that allows users to:
1. Input topics to load Wikipedia content about
2. Ask questions about the loaded topics
3. Receive AI-generated answers based on retrieved context
4. Maintain conversation history for follow-up questions

The interface uses Streamlit for rapid web app development and provides
real-time feedback during content loading and question processing.
"""

import streamlit as st
from src.core.retriever import WikipediaRetriever
from src.core.processor import TextProcessor
from src.database.vector_store import VectorStore, VectorStoreManager
from src.models.qa_chain import QAChain


class ChatbotUI:
    """
    Main UI class for the RAG chatbot web interface.
    
    This class orchestrates the entire user experience by:
    - Managing the Streamlit interface components
    - Coordinating data flow between backend components
    - Handling user interactions and error states
    - Maintaining session state for conversation continuity
    
    The interface consists of:
    - A sidebar for topic loading
    - A main chat area for questions and answers
    - Status indicators and error handling
    """
    
    def __init__(self):
        """
        Initialize the chatbot UI with all necessary backend components.
        
        Creates instances of:
        - WikipediaRetriever: For fetching content from Wikipedia
        - TextProcessor: For chunking text into manageable pieces
        - VectorStore: For storing and retrieving embedded text chunks
        """
        self.retriever = WikipediaRetriever()
        self.processor = TextProcessor()
        self.vector_store = VectorStore()

    def initialize_session_state(self):
        """
        Initialize Streamlit session state variables for maintaining application state.
        
        Session state preserves data across user interactions and page reloads:
        - messages: List of chat messages for conversation history
        - qa_chain: The active question-answering chain
        - vector_store: Reference to the current vector database
        """
        if "messages" not in st.session_state:
            st.session_state.messages = []
        if "qa_chain" not in st.session_state:
            st.session_state.qa_chain = None
        if "vector_store" not in st.session_state:
            st.session_state.vector_store = None

    def run(self):
        """
        Main method to render and run the Streamlit application.
        
        Sets up the page layout with:
        - Page title and header
        - Sidebar for topic input
        - Main area for chat interface
        """
        st.title("WikiChat - RAG-powered Chatbot")
        self.initialize_session_state()

        # Sidebar contains topic loading functionality
        with st.sidebar:
            self.handle_topic_input()

        # Main area contains chat interface
        self.display_chat_messages()
        self.handle_user_input()

    def handle_topic_input(self):
        """
        Handle topic input and loading in the sidebar.
        
        This method:
        1. Provides an input field for users to enter topics
        2. Processes the topic when the "Load Topic" button is clicked
        3. Retrieves Wikipedia content for the topic
        4. Chunks the content and stores it in the vector database
        5. Creates a new QA chain for the loaded content
        6. Provides feedback on the loading process and results
        """
        topic = st.text_input("Enter a topic to learn about:")
        if st.button("Load Topic"):
            with st.spinner("Loading topic information..."):
                try:
                    # Step 1: Retrieve Wikipedia content for the topic
                    wiki_data = self.retriever.get_wiki_data(topic)

                    # Step 2: Process the raw text into manageable chunks
                    chunks = self.processor.split_text(wiki_data)

                    # Step 3: Store chunks in vector database using context manager
                    # The context manager ensures proper cleanup and persistence
                    with VectorStoreManager(self.vector_store) as store:
                        if store is None:
                            # Create new vector store if none exists
                            store = self.vector_store.create_store(chunks)
                        else:
                            # Add new content to existing vector store
                            self.vector_store.add_texts(store, chunks)

                        # Store reference for use in chat functionality
                        st.session_state.vector_store = store

                        # Step 4: Create QA chain with the loaded content
                        st.session_state.qa_chain = QAChain.create_chain(store)

                        # Step 5: Display loading statistics (removed book icon for cleaner look)
                        stats = self.vector_store.get_collection_stats(store)
                        st.sidebar.info(f"Loaded {stats['total_documents']} chunks of information")

                    st.success(f"Loaded information about {topic}")

                except Exception as e:
                    # Provide user-friendly error messages
                    st.error(f"Error loading topic: {str(e)}")

    def handle_user_input(self):
        """
        Process user questions and generate AI responses.
        
        This method:
        1. Captures user input through the chat input widget
        2. Validates that a topic has been loaded
        3. Processes the question through the QA chain
        4. Retrieves relevant context from the vector database
        5. Generates and displays the AI response
        6. Maintains conversation history for context
        """
        if prompt := st.chat_input("Ask a question about the topic"):
            # Ensure a topic has been loaded before allowing questions
            if st.session_state.qa_chain is None:
                st.error("Please load a topic first!")
                return

            try:
                # Add the user's question to the conversation
                self.add_message("user", prompt)

                # Process the question using the QA chain with vector store context
                with VectorStoreManager(self.vector_store) as store:
                    # The QA chain automatically retrieves relevant context
                    # and generates an answer based on the loaded content
                    response = st.session_state.qa_chain({
                        "question": prompt,
                        "chat_history": st.session_state.messages
                    })

                    # Add the AI's response to the conversation
                    self.add_message("assistant", response["answer"])

            except Exception as e:
                # Handle errors gracefully with user-friendly messages
                st.error(f"Error processing question: {str(e)}")

    def add_message(self, role: str, content: str):
        """
        Add a message to the conversation and display it immediately.
        
        Args:
            role (str): The role of the message sender ("user" or "assistant")
            content (str): The content of the message
            
        This method both stores the message in session state for history
        and displays it immediately in the chat interface.
        """
        # Store message in session state for conversation history
        st.session_state.messages.append({"role": role, "content": content})
        
        # Display the message immediately using Streamlit's chat message component
        with st.chat_message(role):
            st.markdown(content)

    def display_chat_messages(self):
        """
        Display all messages in the current conversation.
        
        This method is called when the app loads to restore the conversation
        history from session state. It renders all previous messages in
        chronological order, maintaining the conversation context.
        """
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])


def main():
    """
    Main entry point for the Streamlit application.
    
    Creates and runs the ChatbotUI instance, which handles all
    user interface logic and backend coordination.
    """
    chatbot = ChatbotUI()
    chatbot.run()


# Entry point when running this script directly
if __name__ == "__main__":
    main()