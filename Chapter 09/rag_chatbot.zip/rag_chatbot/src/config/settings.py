"""
Configuration settings for the RAG Chatbot application.

This module contains all configurable parameters for the system, including:
- API keys and authentication
- Wikipedia retrieval settings
- Text processing parameters
- Vector database configuration

All settings are centralized here to make the application easy to configure
and maintain for different environments and use cases.
"""

import os
from dotenv import load_dotenv

# Load environment variables from .env file
# This allows for secure storage of API keys and environment-specific settings
load_dotenv()

# ============================================================================
# API Configuration
# ============================================================================

# OpenAI API key for language model and embeddings
# This should be set in your .env file as: OPENAI_API_KEY=your_key_here
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# ============================================================================
# Wikipedia Retrieval Settings
# ============================================================================

# Language for Wikipedia searches (ISO 639-1 language code)
# Examples: "en" for English, "es" for Spanish, "fr" for French
WIKI_LANGUAGE = "en"

# Maximum number of Wikipedia pages to retrieve per query
# Higher values provide more context but increase processing time and costs
# Recommended range: 1-5 for most use cases
MAX_WIKI_PAGES = 2

# ============================================================================
# Text Processing Configuration
# ============================================================================

# Size of each text chunk in characters
# This affects the granularity of information retrieval and embedding quality
# Recommended range: 500-2000 characters
# - Smaller chunks: More precise retrieval but may lose context
# - Larger chunks: Better context preservation but less precise matching
CHUNK_SIZE = 1000

# Number of overlapping characters between adjacent chunks
# This helps maintain context continuity across chunk boundaries
# Should typically be 10-20% of CHUNK_SIZE
CHUNK_OVERLAP = 200

# ============================================================================
# Vector Database Configuration
# ============================================================================

# Path where the vector database will be stored
# This is a local directory that will contain ChromaDB files
# The directory will be created automatically if it doesn't exist
VECTOR_STORE_PATH = "data/vector_store"