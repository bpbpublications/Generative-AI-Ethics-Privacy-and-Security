# Import YAML parser for configuration file handling
import yaml
# Import OS interface for environment variable access
import os


class Config:
    """
    Configuration management class for handling application settings.
    Supports both YAML config files and environment variables.
    """

    def __init__(self):
        """
        Initialize configuration manager.
        Sets the config file path and loads configuration data.
        """
        # Define path to configuration file
        self.config_path = "config/config.yaml"
        # Load configuration data from file
        self.load_config()

    def load_config(self):
        """
        Load configuration data from YAML file.
        Parses the YAML configuration file and stores data in self.config.
        
        Raises:
            FileNotFoundError: If config file doesn't exist
            yaml.YAMLError: If YAML file is malformed
        """
        with open(self.config_path, 'r') as file:
            # Parse YAML file content safely (prevents code execution)
            self.config = yaml.safe_load(file)

    def get_api_key(self):
        """
        Retrieve OpenAI API key from environment variables or config file.
        
        Returns:
            str: OpenAI API key from environment variable or config file
                 Environment variable takes precedence over config file
                 
        Note:
            Checks environment variable first, then falls back to config file.
            This allows for secure deployment without exposing keys in files.
        """
        # Try environment variable first (more secure), fallback to config file
        return os.getenv("OPENAI_API_KEY") or self.config.get("openai_api_key")