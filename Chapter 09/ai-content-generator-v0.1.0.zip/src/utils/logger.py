# Import logging functionality for application monitoring
import logging
# Import OS interface for directory operations
import os

# Create logs directory if it doesn't exist
logs_dir = "logs"
if not os.path.exists(logs_dir):
    # Create directory with all necessary parent directories
    os.makedirs(logs_dir)

# Configure application-wide logging settings
logging.basicConfig(
    # Set minimum log level to INFO (excludes DEBUG messages)
    level=logging.INFO,
    # Define log message format with timestamp, module name, level, and message
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    # Configure multiple output handlers
    handlers=[
        # Log to file for persistent storage and debugging
        logging.FileHandler(os.path.join(logs_dir, 'app.log')),
        # Log to console for real-time monitoring during development
        logging.StreamHandler()
    ]
)

# Create module-specific logger instance
# This allows tracking which module generated each log message
logger = logging.getLogger(__name__)