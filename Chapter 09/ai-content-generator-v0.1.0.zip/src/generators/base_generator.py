# Import required libraries
import openai  # OpenAI API interface
import os  # Operating system interface for environment variables
import logging  # Logging functionality

# Initialize logger for this module
logger = logging.getLogger(__name__)


class BaseGenerator:
    """
    Base class for content generation using OpenAI's API.
    Provides common functionality for all content generators.
    """

    def __init__(self):
        """
        Initialize the generator with API credentials.
        Retrieves API key from environment variables and configures OpenAI client.
        """
        # Get API key from environment variables
        self.api_key = os.getenv("OPENAI_API_KEY")
        # Configure OpenAI with API key
        openai.api_key = self.api_key

    def generate_content(self, prompt, model="gpt-4", max_tokens=500):
        """
        Generate content using OpenAI's API.

        Args:
            prompt (str): The input prompt for content generation
            model (str, optional): GPT model to use. Defaults to "gpt-4"
            max_tokens (int, optional): Maximum length of generated content. Defaults to 500

        Returns:
            str: Generated content text or None if generation fails

        Note:
            Uses chat completion API with system and user messages
            Temperature of 0.7 provides balance between creativity and consistency
        """
        try:
            # Make API call to OpenAI's chat completion endpoint
            response = openai.chat.completions.create(
                model=model,  # Specify GPT model
                messages=[
                    # Set system role as content creator
                    {"role": "system", "content": "You are an expert content creator."},
                    # User prompt for content generation
                    {"role": "user", "content": prompt}
                ],
                max_tokens=max_tokens,  # Limit response length
                temperature=0.7  # Control randomness in generation
            )

            # Extract and clean the generated content
            return response.choices[0].message.content.strip()

        except Exception as e:
            # Log any errors that occur during generation
            logger.error(f"Error generating content: {str(e)}")
            return None


