# Import logging functionality for tracking execution
import logging

# Import base generator class for content generation capabilities
from src.generators.base_generator import BaseGenerator

# Initialize logger for this module
logger = logging.getLogger(__name__)


class MarketingGenerator(BaseGenerator):
    """
    Specialized generator class for creating marketing copy.
    Converts detailed articles into concise, persuasive marketing content.
    Inherits from BaseGenerator for content generation functionality.
    """

    def create_marketing_copy(self, article):
        """
        Transform an article into compelling marketing copy.

        Args:
            article (str): Source article to extract marketing content from

        Returns:
            str: Generated marketing copy or None if generation fails

        Note:
            - Creates catchy, attention-grabbing content
            - Focuses on key benefits and taglines
            - Limited to 300 tokens for concise messaging
        """
        # Log the marketing copy generation process
        logger.info("Generating marketing copy")

        # Construct prompt with specific instructions for marketing content
        prompt = f"Based on the following article, create a catchy marketing copy:\n{article}\nFocus on taglines and key benefits."

        # Generate and return marketing copy using base generator
        return self.generate_content(prompt, max_tokens=300)


