# Import logging for tracking execution and debugging
import logging

# Import base generator class that provides common functionality
from src.generators.base_generator import BaseGenerator

# Initialize logger for this module
logger = logging.getLogger(__name__)


class ArticleGenerator(BaseGenerator):
    """
    Specialized generator class for creating full-length articles.
    Inherits from BaseGenerator to utilize common generation capabilities.
    """

    def write_article(self, topic):
        """
        Generate a detailed article on the given topic.

        Args:
            topic (str): The main topic/subject for the article

        Returns:
            str: Generated article text or None if generation fails

        Note:
            - Uses GPT model to generate comprehensive article
            - Includes introduction, key points, and conclusion
            - Maximum token length set to 1000 for detailed content
        """
        # Log the generation attempt for tracking
        logger.info(f"Generating article for topic: {topic}")

        # Construct the prompt with specific instructions for article structure
        prompt = f"Write a detailed article on the topic: {topic}. Include an introduction, key points, and a conclusion."

        # Generate and return the article using the base generator's functionality
        return self.generate_content(prompt, max_tokens=1000)

