# Import logging functionality for tracking execution
import logging

# Import base generator class for content generation capabilities
from src.generators.base_generator import BaseGenerator

# Initialize logger for this module
logger = logging.getLogger(__name__)


class BlogGenerator(BaseGenerator):
    """
    Specialized generator class for creating blog posts.
    Converts formal articles into more conversational blog format.
    Inherits from BaseGenerator for content generation functionality.
    """

    def adapt_to_blog_post(self, article):
        """
        Transform a formal article into a blog post format.

        Args:
            article (str): Original article text to be converted

        Returns:
            str: Converted blog post or None if generation fails

        Note:
            - Maintains core content while making tone more conversational
            - Adds subheadings for better readability
            - Sets maximum length to 800 tokens for optimal blog length
        """
        # Log the adaptation process
        logger.info("Adapting article to blog post format")

        # Construct prompt with specific instructions for blog adaptation
        prompt = f"Adapt the following article into a blog post with a conversational tone:\n{article}\nInclude subheadings and make it engaging."

        # Generate and return the blog post using base generator
        return self.generate_content(prompt, max_tokens=800)


