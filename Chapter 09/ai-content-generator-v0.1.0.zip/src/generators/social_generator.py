# Import logging functionality for tracking execution
import logging

# Import base generator class for content generation capabilities
from src.generators.base_generator import BaseGenerator

# Initialize logger for this module
logger = logging.getLogger(__name__)


class SocialMediaGenerator(BaseGenerator):
    """
    Specialized generator class for creating platform-specific social media content.
    Adapts articles into appropriate formats for different social platforms.
    Inherits from BaseGenerator for content generation functionality.
    """

    def __init__(self):
        """
        Initialize social media generator with platform-specific instructions.
        Calls parent class initializer and sets up platform requirements.
        """
        # Initialize parent class (BaseGenerator)
        super().__init__()

        # Define platform-specific generation instructions
        self.platforms = {
            "Twitter": "Create a tweet summarizing the article in under 280 characters.",
            "Instagram": "Create an engaging Instagram caption based on the article. Include hashtags and emojis.",
            "LinkedIn": "Create a professional LinkedIn post summarizing the article and its key takeaways."
        }

    def generate_social_media_posts(self, article):
        """
        Create platform-optimized posts from an article.

        Args:
            article (str): Source article to create social media posts from

        Returns:
            dict: Dictionary of generated posts for each platform
                 {platform_name: generated_content}

        Note:
            - Generates content specific to each platform's style
            - Twitter: Short, concise (280 chars)
            - Instagram: Visual, engaging, with hashtags
            - LinkedIn: Professional, detailed takeaways
            - Limited to 200 tokens per post
        """
        # Initialize dictionary to store posts for each platform
        posts = {}

        # Generate content for each platform
        for platform, task in self.platforms.items():
            # Log generation process for each platform
            logger.info(f"Generating content for {platform}")

            # Construct platform-specific prompt
            prompt = f"{task}\nArticle: {article}"

            # Generate and store content for this platform
            posts[platform] = self.generate_content(prompt, max_tokens=200)

        return posts


