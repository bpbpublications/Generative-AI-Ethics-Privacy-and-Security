# Import required system libraries
import os  # Operating system interface
import sys  # System-specific parameters
import logging  # Logging functionality

# Import content generator modules
from src.generators.article_generator import ArticleGenerator  # Article generation
from src.generators.blog_generator import BlogGenerator  # Blog post generation
from src.generators.marketing_generator import MarketingGenerator  # Marketing copy generation
from src.generators.social_generator import SocialMediaGenerator  # Social media post generation

# Initialize logger for this module
logger = logging.getLogger(__name__)


class ContentPipeline:
    """
    Orchestrates the content generation process across different content types.
    Manages multiple content generators and coordinates their execution.
    """

    def __init__(self):
        """Initialize different content generator instances"""
        self.article_gen = ArticleGenerator()  # For generating articles
        self.blog_gen = BlogGenerator()  # For generating blog posts
        self.marketing_gen = MarketingGenerator()  # For generating marketing copy
        self.social_gen = SocialMediaGenerator()  # For generating social media posts

    def generate_all_content(self, topic):
        """
        Generate all types of content for a given topic.

        Args:
            topic (str): The main topic for content generation

        Returns:
            dict: Dictionary containing all generated content types
                  or None if article generation fails
        """
        # First generate the main article
        article = self.article_gen.write_article(topic)
        if not article:
            logger.error("Failed to generate article")
            return

        # Generate derivative content from the main article
        blog_post = self.blog_gen.adapt_to_blog_post(article)
        marketing_copy = self.marketing_gen.create_marketing_copy(article)
        social_posts = self.social_gen.generate_social_media_posts(article)

        # Return all generated content in a structured format
        return {
            "article": article,
            "blog_post": blog_post,
            "marketing_copy": marketing_copy,
            "social_posts": social_posts
        }


def main():
    """
    Main function to execute the content generation pipeline.
    Gets user input and displays generated content.
    """
    # Initialize the content generation pipeline
    pipeline = ContentPipeline()

    # Get topic from user input
    topic = input("Enter the topic: ")

    # Generate all content types
    content = pipeline.generate_all_content(topic)

    # Display generated content if successful
    if content:
        print("\n=== Article ===\n", content["article"])
        print("\n=== Blog Post ===\n", content["blog_post"])
        print("\n=== Marketing Copy ===\n", content["marketing_copy"])
        for platform, post in content["social_posts"].items():
            print(f"\n=== {platform} Post ===\n", post)


# Execute main() if script is run directly
if __name__ == "__main__":
    main()
