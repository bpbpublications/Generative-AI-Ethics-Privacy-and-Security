# AI Content Generation Pipeline

An educational Python project demonstrating AI-powered content generation using OpenAI's GPT models.

## 🎯 Project Overview
The AI Content Generation Pipeline is a sophisticated Python-based tool that leverages OpenAI's GPT models to automate and streamline content creation across multiple formats. Built for content creators, marketing teams, and businesses, this tool can automatically generate high-quality articles, blog posts, marketing copy, and social media content while maintaining consistency in tone and messaging.

## ✨ Key Features
- **🎯 Multi-format Content Generation**
  - Articles and Blog Posts
  - Marketing Copy
  - Social Media Posts (Twitter, LinkedIn, Instagram)
  - Video Scripts
- **🤖 AI-Powered Intelligence**
  - Context-aware content creation
  - Consistent brand voice
  - SEO-optimized content
- **⚡ Efficient Workflow**
  - Batch content generation
  - Customizable outputs
  - Content repurposing

## 🚀 Installation

### Prerequisites
- Python 3.7 or higher
- OpenAI API key
- Virtual environment (recommended)

### Setup
1. **Clone the repository:**
```bash
git clone https://github.com/yourusername/content-generator.git
cd content-generator
```

2. **Create and activate virtual environment:**
```bash
# Create virtual environment
python -m venv .venv

# Activate virtual environment
# On Windows:
.venv\Scripts\activate
# On macOS/Linux:
source .venv/bin/activate
```

3. **Install required packages:**
```bash
pip install -r requirements.txt
```

4. **Set up environment variables:**
   - Create a `.env` file in the root directory
   - Add your OpenAI API key:
```
OPENAI_API_KEY=your-api-key-here
```

## 📖 Usage

### Basic Usage
1. **Run the main program:**
```bash
python run.py
```

2. **Enter the topic when prompted**

3. **The program will generate:**
   - Detailed article
   - Blog post version
   - Marketing copy
   - Social media posts

### Advanced Usage
```python
from src.main import ContentPipeline

# Initialize the pipeline
pipeline = ContentPipeline()

# Generate content
content = pipeline.generate_all_content("Your Topic Here")

# Access different content types
article = content["article"]
blog_post = content["blog_post"]
marketing_copy = content["marketing_copy"]
social_posts = content["social_posts"]
```

## 📁 Project Structure
```
content_generator/
├── src/
│   ├── generators/         # Content generation modules
│   │   ├── base_generator.py      # Base class for all generators
│   │   ├── article_generator.py   # Article generation logic
│   │   ├── blog_generator.py      # Blog post adaptation
│   │   ├── marketing_generator.py # Marketing copy creation
│   │   └── social_generator.py    # Social media posts
│   ├── utils/             # Utility functions
│   │   ├── config.py      # Configuration management
│   │   └── logger.py      # Logging setup
│   └── main.py            # Main pipeline orchestration
├── logs/                  # Log files
├── config/                # Configuration files
├── run.py                 # Entry point
└── requirements.txt       # Dependencies
```

## ⚙️ Configuration
- Adjust generation parameters in `config/config.yaml`
- Modify content templates in respective generator modules
- Configure logging in `src/utils/logger.py`

## 🤝 Contributing
We welcome contributions! This project is designed for educational purposes.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License
Distributed under the MIT License. See `LICENSE` for more information.

## 🎓 Educational Purpose
This project is designed to demonstrate:
- Object-oriented programming in Python
- API integration with OpenAI
- Modular code architecture
- Configuration management
- Logging best practices
- Package structure and distribution

## 📞 Contact
Project Link: [https://github.com/yourusername/content-generator](https://github.com/yourusername/content-generator)

## 🔧 Troubleshooting
- Ensure your OpenAI API key is valid and has sufficient credits
- Check that all dependencies are installed correctly
- Review log files in the `logs/` directory for detailed error information

