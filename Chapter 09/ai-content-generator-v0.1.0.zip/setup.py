"""
Setup Configuration for Content Generator Package

This script configures the Python package installation using setuptools.
It defines package metadata and dependencies required for installation.
"""

from setuptools import setup, find_packages

# Read long description from README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    # Name of the package as it will appear on PyPI
    name="ai-content-generator",

    # Version number following semantic versioning (major.minor.patch)
    version="0.1.0",

    # Author information
    author="Content Generator Project",
    author_email="contact@example.com",

    # Short description of the package
    description="An educational AI-powered content generation pipeline using OpenAI GPT models",

    # Long description from README file
    long_description=long_description,
    long_description_content_type="text/markdown",

    # URL to the project homepage
    url="https://github.com/yourusername/content-generator",

    # Project URLs for additional links
    project_urls={
        "Bug Reports": "https://github.com/yourusername/content-generator/issues",
        "Source": "https://github.com/yourusername/content-generator",
        "Documentation": "https://github.com/yourusername/content-generator#readme",
    },

    # Automatically find all packages in the project
    # find_packages() searches for directories containing __init__.py files
    packages=find_packages(),

    # Python version requirement
    python_requires=">=3.7",

    # List of required dependencies that will be installed with the package
    install_requires=[
        'openai>=1.0.0',  # OpenAI API client library
        'python-dotenv>=0.19.0',  # For loading environment variables
        'pyyaml>=6.0'  # For parsing YAML configuration files
    ],

    # Package classifiers for PyPI categorization
    classifiers=[
        # Project maturity
        "Development Status :: 3 - Alpha",

        # Target audience
        "Intended Audience :: Developers",
        "Intended Audience :: Education",

        # License
        "License :: OSI Approved :: MIT License",

        # Python versions supported
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",

        # Topic categories
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Text Processing :: Linguistic",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],

    # Keywords for package discovery
    keywords="ai, content-generation, openai, gpt, educational, python",

    # Entry points for command-line scripts
    entry_points={
        "console_scripts": [
            "content-generator=run:main",
        ],
    },

    # Include additional files specified in MANIFEST.in
    include_package_data=True,

    # Specify which files to include in the distribution
    package_data={
        "": ["*.md", "*.txt", "*.yaml", "*.yml"],
    },
)
