# Import required system and environment management libraries
import os                  # Operating system interface for file/directory operations
import sys                 # System-specific parameters and functions
from dotenv import load_dotenv  # Load environment variables from .env file
import logging            # Logging functionality


def setup_environment():
    """
    Initialize application environment by:
    - Loading environment variables
    - Verifying API keys
    - Setting up Python path
    - Configuring logging
    """
    # Load variables from .env file into environment
    load_dotenv()

    # Check if required API key exists in environment variables
    if not os.getenv("OPENAI_API_KEY"):
        raise ValueError("OPENAI_API_KEY not found in environment variables. Please check your .env file.")

    # Get absolute path of current script and add to Python path
    project_root = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(project_root)

    # Create directory for log files if it doesn't exist
    logs_dir = os.path.join(project_root, 'logs')
    os.makedirs(logs_dir, exist_ok=True)

    # Configure logging with both file and console output
    logging.basicConfig(
        level=logging.INFO,                     # Set logging level
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',  # Log message format
        handlers=[
            logging.FileHandler(os.path.join(logs_dir, 'app.log')),  # Log to file
            logging.StreamHandler()                                   # Log to console
        ]
    )


def main():
    """
    Main entry point of the application.
    Handles environment setup and error management.
    """
    try:
        # Initialize environment before running main program
        setup_environment()

        # Import main function after environment is setup
        from src.main import main as content_main

        # Execute main program logic
        content_main()

    except ImportError as e:
        # Handle module import errors
        print(f"Error importing required modules: {str(e)}")
        print("Please ensure all requirements are installed and the project structure is correct.")
        print(f"Python path: {sys.path}")
        sys.exit(1)
    except ValueError as e:
        # Handle configuration/validation errors
        print(f"Configuration error: {str(e)}")
        sys.exit(1)
    except Exception as e:
        # Handle unexpected errors
        print(f"An unexpected error occurred: {str(e)}")
        logging.exception("Unexpected error in main")
        sys.exit(1)


# Execute main() if script is run directly
if __name__ == "__main__":
    main()
